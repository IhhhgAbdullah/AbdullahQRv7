import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:flutter/rendering.dart';
import 'package:archive/archive.dart';
import 'package:cryptography/cryptography.dart';
import 'package:share_plus/share_plus.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:google_sign_in/google_sign_in.dart';
import 'package:gal/gal.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:qr/qr.dart' as qr;
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String kServerUrl = 'https://887899Abdullah.pythonanywhere.com';
const String kGoogleWebClientId = '1043319001950-4jtv9ofmkghio9i2d814l1shep7sq1g7.apps.googleusercontent.com';

final fontScale = ValueNotifier<double>(1.0);
final langNotifier = ValueNotifier<String>('ar');
String appLang = 'ar';

String tr(String ar, String en, String zh) {
  if (appLang == 'en') return en;
  if (appLang == 'zh') return zh;
  return ar;
}

void main() => runApp(QrPixApp());

class QrPixApp extends StatelessWidget {
  QrPixApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QR PiX',
      debugShowCheckedModeBanner: false,
      builder: (context, child) => ValueListenableBuilder<String>(
        valueListenable: langNotifier,
        builder: (c0, lang, _) => Directionality(
          textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
          child: ValueListenableBuilder<double>(
            valueListenable: fontScale,
            builder: (c, scale, _) => MediaQuery(
              data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(scale)),
              child: child!,
            ),
          ),
        ),
      ),
      theme: ThemeData(
        brightness: Brightness.dark,
        colorSchemeSeed: Color(0xFF1E88E5),
        useMaterial3: true,
      ),
      home: HomePage(),
    );
  }
}

class PickedItem {
  final String name;
  final Uint8List bytes;
  final bool isImage;
  PickedItem(this.name, this.bytes, this.isImage);
}

class HomePage extends StatefulWidget {
  HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _serverCtrl = TextEditingController();
  final _keyCtrl = TextEditingController();
  final _codeCtrl = TextEditingController();
  final _cName = TextEditingController();
  final _cTitle = TextEditingController();
  final _cCompany = TextEditingController();
  final _cPhone = TextEditingController();
  final _cEmail = TextEditingController();
  final _cWeb = TextEditingController();
  final _filePassCtrl = TextEditingController();
  final _cardKey = GlobalKey();
  String? _cardData;
  int _expireSeconds = 0;
  List<Map<String, dynamic>> _stats = [];
  final _dynUrlCtrl = TextEditingController();
  final _evTitle = TextEditingController();
  final _evDate = TextEditingController();
  final _evPlace = TextEditingController();
  final _evNote = TextEditingController();
  final _dynKey = GlobalKey();
  final _evKey = GlobalKey();
  String? _dynQr;
  String? _evQr;
  List<Map<String, dynamic>> _dynList = [];
  List<Map<String, dynamic>> _evList = [];
  final _wifiSsid = TextEditingController();
  final _wifiPass = TextEditingController();
  final _mapCtrl = TextEditingController();
  String _wifiType = 'WPA';
  String? _wifiQr;
  String? _mapQr;
  final _wifiKey = GlobalKey();
  final _mapKey = GlobalKey();
  final _picker = ImagePicker();

  final List<PickedItem> _items = [];
  String? _qrData;
  String _status = tr('اختر ملفات أو صور أولًا', 'Pick files or photos first', '请先选择文件或照片');
  bool _busy = false;
  String? _token;
  Color _qrColor = Color(0xFF0B1D3A);
  Uint8List? _logoBytes;
  Offset _logoPos = Offset(92, 92);
  List<List<String>> _batchRows = [];
  int _batchCount = 0;
  final _qrKey = GlobalKey();
  final _googleSignIn = GoogleSignIn(
    scopes: ['email', 'https://www.googleapis.com/auth/drive.file'],
    serverClientId: kGoogleWebClientId,
  );
  String _email = '';
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  @override
  void dispose() {
    _serverCtrl.dispose();
    _keyCtrl.dispose();
    _codeCtrl.dispose();
    _cName.dispose();
    _cTitle.dispose();
    _cCompany.dispose();
    _cPhone.dispose();
    _cEmail.dispose();
    _cWeb.dispose();
    _filePassCtrl.dispose();
    _dynUrlCtrl.dispose();
    _evTitle.dispose();
    _evDate.dispose();
    _evPlace.dispose();
    _evNote.dispose();
    _wifiSsid.dispose();
    _wifiPass.dispose();
    _mapCtrl.dispose();
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadSettings() async {
    final p = await SharedPreferences.getInstance();
    _serverCtrl.text = kServerUrl;
    fontScale.value = p.getDouble('font_scale') ?? 1.0;
    appLang = p.getString('lang') ?? 'ar';
    langNotifier.value = appLang;
    if (mounted) {
      setState(() {
        _token = p.getString('token');
        _email = p.getString('email') ?? '';
      });
    }
  }

  Future<void> _auth(String mode) async {
    final email = _emailCtrl.text.trim().toLowerCase();
    final pass = _passCtrl.text;
    if (!email.contains('@') || pass.length < 6) {
      _say('أدخل بريد صحيح وكلمة سر 6 أحرف على الأقل');
      return;
    }
    setState(() => _busy = true);
    try {
      final res = await http.post(
        Uri.parse('${_serverBase()}/$mode'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email, 'password': pass}),
      ).timeout(Duration(seconds: 30));
      final j = jsonDecode(res.body) as Map<String, dynamic>;
      if (res.statusCode != 200 || j['token'] == null) {
        throw Exception(j['error'] ?? 'HTTP ${res.statusCode}');
      }
      final p = await SharedPreferences.getInstance();
      await p.setString('token', j['token'] as String);
      await p.setString('email', email);
      _passCtrl.clear();
      if (mounted) {
        setState(() {
          _token = j['token'] as String;
          _email = email;
          _status = tr('أهلًا بك', 'Welcome', '欢迎');
        });
      }
    } catch (e) {
      _say('خطأ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _googleLogin() async {
    setState(() => _busy = true);
    try {
      final acc = await _googleSignIn.signIn().timeout(Duration(seconds: 60));
      if (acc == null) {
        _say('تم إلغاء تسجيل الدخول');
        return;
      }
      final auth = await acc.authentication;
      final idToken = auth.idToken;
      if (idToken == null) throw Exception('ما وصل توكن من Google');
      final res = await http.post(
        Uri.parse('${_serverBase()}/google'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'idToken': idToken}),
      ).timeout(Duration(seconds: 30));
      final j = jsonDecode(res.body) as Map<String, dynamic>;
      if (res.statusCode != 200 || j['token'] == null) {
        throw Exception(j['error'] ?? 'HTTP ${res.statusCode}');
      }
      final p = await SharedPreferences.getInstance();
      await p.setString('token', j['token'] as String);
      await p.setString('email', j['email'] as String);
      if (mounted) {
        setState(() {
          _token = j['token'] as String;
          _email = j['email'] as String;
          _status = tr('أهلًا بك', 'Welcome', '欢迎');
        });
      }
    } catch (e) {
      _say('خطأ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _logout() async {
    final p = await SharedPreferences.getInstance();
    await p.remove('token');
    await p.remove('email');
    if (mounted) {
      setState(() {
        _token = null;
        _email = '';
        _items.clear();
        _qrData = null;
        _status = 'تم تسجيل الخروج';
      });
    }
  }

  Future<void> _openFontSheet() async {
    await showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => ValueListenableBuilder<double>(
        valueListenable: fontScale,
        builder: (c, v, _) => Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(tr('حجم الخط', 'Font size', '字体大小'), style: TextStyle(fontWeight: FontWeight.bold)),
              Wrap(
                spacing: 8,
                children: [
                  for (final e in [['ar', 'العربية'], ['en', 'English'], ['zh', '中文']])
                    ChoiceChip(
                      label: Text(e[1]),
                      selected: appLang == e[0],
                      onSelected: (_) async {
                        appLang = e[0];
                        langNotifier.value = e[0];
                        final p = await SharedPreferences.getInstance();
                        await p.setString('lang', e[0]);
                        setState(() {});
                      },
                    ),
                ],
              ),
              SizedBox(height: 10),
              Slider(
                value: v,
                min: 0.85,
                max: 1.5,
                divisions: 13,
                label: v.toStringAsFixed(2),
                onChanged: (x) async {
                  fontScale.value = x;
                  final p = await SharedPreferences.getInstance();
                  await p.setDouble('font_scale', x);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _exportPdf() async {
    final data = _qrData;
    if (data == null) return;
    try {
      final doc = pw.Document();
      doc.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          build: (ctx) => pw.Center(
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.center,
              children: [
                pw.Text('QR PiX', style: pw.TextStyle(fontSize: 28, fontWeight: pw.FontWeight.bold)),
                pw.SizedBox(height: 30),
                pw.BarcodeWidget(
                  barcode: pw.Barcode.qrCode(),
                  data: data,
                  width: 320,
                  height: 320,
                ),
                pw.SizedBox(height: 20),
                pw.Text(data, style: pw.TextStyle(fontSize: 10)),
              ],
            ),
          ),
        ),
      );
      final bytes = await doc.save();
      await Share.shareXFiles(
        [XFile.fromData(bytes, name: 'qr_pix.pdf', mimeType: 'application/pdf')],
        text: 'QR PiX',
      );
      _say('تم تجهيز ملف PDF');
    } catch (e) {
      _say('تعذر التصدير: $e');
    }
  }

  Future<void> _saveSettings() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('server', _serverCtrl.text.trim());
    await p.setString('upkey', _keyCtrl.text.trim());
    _say('تم حفظ الإعدادات');
  }

  void _say(String s) {
    if (mounted) setState(() => _status = s);
  }

  void _changed() {
    setState(() {
      _qrData = null;
      _status = 'عدد الملفات: ${_items.length}';
    });
  }

  Future<void> _pickFiles() async {
    final group = XTypeGroup(
      label: 'PDF والصور',
      extensions: ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'gif'],
    );
    final files = await openFiles(acceptedTypeGroups: [group]);
    for (final f in files) {
      final bytes = await f.readAsBytes();
      final ext = f.name.split('.').last.toLowerCase();
      final isImage = ['jpg', 'jpeg', 'png', 'webp', 'gif'].contains(ext);
      _items.add(PickedItem(f.name, bytes, isImage));
    }
    _changed();
  }

  Future<void> _pickMany() async {
    final files = await _picker.pickMultiImage(imageQuality: 100);
    for (final f in files) {
      _items.add(PickedItem(f.name, await f.readAsBytes(), true));
    }
    if (files.isNotEmpty) {
      _changed();
    }
  }

  Future<void> _openGallery() async {
    // The system photo picker opens without a permission prompt.
    await _pickMany();
  }

  void _openAlbum() {
    final url = _qrData;
    if (url == null) return;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => AlbumPage(url: url)));
  }

  List<List<String>> _parseCsv(Uint8List bytes) {
    final text = utf8.decode(bytes, allowMalformed: true);
    return text
        .split(RegExp(r'\r?\n'))
        .where((l) => l.trim().isNotEmpty)
        .map((l) => l.split(',').map((c) => c.trim().replaceAll('"', '')).toList())
        .toList();
  }

  String _unescapeXml(String v) => v
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>')
      .replaceAll('&quot;', '"')
      .replaceAll('&apos;', "'")
      .replaceAll('&amp;', '&');

  int _colIndex(String letters) {
    var n = 0;
    for (final ch in letters.codeUnits) {
      n = n * 26 + (ch - 64);
    }
    return n - 1;
  }

  // Reads every sheet of an .xlsx file and returns the rows of the sheet that has the most links
  List<List<String>> _parseXlsx(Uint8List bytes) {
    final arc = ZipDecoder().decodeBytes(bytes);
    String? readFile(String name) {
      for (final f in arc.files) {
        if (f.isFile && f.name == name) {
          return utf8.decode(f.content as List<int>, allowMalformed: true);
        }
      }
      return null;
    }

    final shared = <String>[];
    final sst = readFile('xl/sharedStrings.xml');
    if (sst != null) {
      for (final m in RegExp(r'<si>(.*?)</si>', dotAll: true).allMatches(sst)) {
        final text = RegExp(r'<t[^>]*>(.*?)</t>', dotAll: true)
            .allMatches(m.group(1)!)
            .map((x) => _unescapeXml(x.group(1)!))
            .join();
        shared.add(text);
      }
    }

    List<List<String>> parseSheet(String xml) {
      final rows = <List<String>>[];
      for (final rm in RegExp(r'<row[^>]*>(.*?)</row>', dotAll: true).allMatches(xml)) {
        final cells = <int, String>{};
        for (final cm in RegExp(r'<c ([^>]*?)(?:/>|>(.*?)</c>)', dotAll: true).allMatches(rm.group(1)!)) {
          final attrs = cm.group(1)!;
          final body = cm.group(2) ?? '';
          final ref = RegExp(r'r="([A-Z]+)\d+"').firstMatch(attrs)?.group(1) ?? 'A';
          final type = RegExp(r't="([^"]+)"').firstMatch(attrs)?.group(1);
          String value = '';
          if (type == 's') {
            final idx = int.tryParse(RegExp(r'<v>(\d+)</v>').firstMatch(body)?.group(1) ?? '');
            if (idx != null && idx < shared.length) value = shared[idx];
          } else if (type == 'inlineStr') {
            value = RegExp(r'<t[^>]*>(.*?)</t>', dotAll: true)
                .allMatches(body)
                .map((x) => _unescapeXml(x.group(1)!))
                .join();
          } else {
            value = _unescapeXml(RegExp(r'<v>(.*?)</v>', dotAll: true).firstMatch(body)?.group(1) ?? '');
          }
          cells[_colIndex(ref)] = value.trim();
        }
        if (cells.isEmpty) {
          rows.add([]);
          continue;
        }
        final maxCol = cells.keys.reduce((x, y) => x > y ? x : y);
        rows.add(List.generate(maxCol + 1, (i) => cells[i] ?? ''));
      }
      return rows;
    }

    List<List<String>> best = [];
    int bestLinks = -1;
    for (final f in arc.files) {
      if (!f.isFile || !f.name.startsWith('xl/worksheets/sheet') || !f.name.endsWith('.xml')) continue;
      final rows = parseSheet(utf8.decode(f.content as List<int>, allowMalformed: true));
      final links = rows.where((r) => r.any((c) => c.toLowerCase().startsWith('http'))).length;
      if (links > bestLinks) {
        bestLinks = links;
        best = rows;
      }
    }
    if (bestLinks < 0) throw Exception('ما لقيت ورقة في الملف');
    return best;
  }

  Future<void> _pickBatchFile() async {
    final group = XTypeGroup(
      label: 'Excel أو CSV',
      extensions: ['xlsx', 'csv'],
      mimeTypes: [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-excel',
        'text/csv',
        'application/octet-stream',
      ],
    );
    final file = await openFile(acceptedTypeGroups: [group]).timeout(Duration(seconds: 120));
    if (file == null) {
      _say('ما اخترت ملف');
      return;
    }
    _say('تم اختيار: ${file.name}');
    try {
      final bytes = await file.readAsBytes();
      _say('تم تحميل الملف (${bytes.length} بايت)، جاري التحليل...');
      final isCsv = file.name.toLowerCase().endsWith('.csv');
      final rows = isCsv ? _parseCsv(bytes) : _parseXlsx(bytes);
      _say('تم تحليل ${rows.length} صف، جاري البحث عن الروابط...');
      final valid = <List<String>>[];
      for (final r in rows) {
        final li = r.indexWhere((c) => c.toLowerCase().startsWith('http'));
        if (li < 0) continue;
        var name = '';
        for (var i = 0; i < r.length; i++) {
          if (i != li && r[i].isNotEmpty && !r[i].toLowerCase().startsWith('http')) {
            name = r[i];
            break;
          }
        }
        valid.add([r[li], name]);
      }
      if (valid.isEmpty) {
        _say('ما لقيت روابط (http) في الملف');
        return;
      }
      final limited = valid.take(500).toList();
      setState(() {
        _batchRows = limited;
        _batchCount = limited.length;
      });
      _say('تم قراءة $_batchCount رابط${valid.length > 500 ? ' (أول 500 فقط)' : ''}');
    } catch (e) {
      _say('تعذر قراءة الملف: $e');
    }
  }

  Future<Uint8List> _qrPngBytes(String data) async {
    double size = 600;
    final painter = QrPainter(data: data, version: QrVersions.auto, gapless: true);
    final recorder = ui.PictureRecorder();
    final canvas = ui.Canvas(recorder, ui.Rect.fromLTWH(0, 0, size, size));
    canvas.drawRect(ui.Rect.fromLTWH(0, 0, size, size), ui.Paint()..color = Colors.white);
    painter.paint(canvas, Size(size, size));
    final picture = recorder.endRecording();
    final image = await picture.toImage(size.toInt(), size.toInt());
    final bd = await image.toByteData(format: ui.ImageByteFormat.png);
    return bd!.buffer.asUint8List();
  }

  Future<void> _makeBatchZip() async {
    if (_batchRows.isEmpty) {
      _say('اختر ملف Excel أو CSV أولًا');
      return;
    }
    setState(() => _busy = true);
    try {
      final archive = Archive();
      for (var i = 0; i < _batchRows.length; i++) {
        _say('إنشاء الرمز ${i + 1} من ${_batchRows.length}...');
        final row = _batchRows[i];
        final rawName = row.length > 1 && row[1].isNotEmpty ? row[1] : 'qr_${i + 1}';
        final safe = rawName.replaceAll(RegExp(r'[^A-Za-z0-9\u0600-\u06FF_-]+'), '_');
        final png = await _qrPngBytes(row[0]);
        archive.addFile(ArchiveFile('${i + 1}_$safe.png', png.length, png));
      }
      final encoded = ZipEncoder().encode(archive);
      if (encoded == null) throw Exception('تعذر إنشاء ملف ZIP');
      final zipBytes = Uint8List.fromList(encoded);
      await Share.shareXFiles(
        [XFile.fromData(zipBytes, name: 'qr_codes.zip', mimeType: 'application/zip')],
        text: 'QR PiX - رموز QR جماعية',
      );
      _say('تم إنشاء ${_batchRows.length} رمز في ملف ZIP');
    } catch (e) {
      _say('خطأ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _pickCamera() async {
    final f = await _picker.pickImage(source: ImageSource.camera, imageQuality: 100);
    if (f == null) return;
    _items.add(PickedItem(f.name, await f.readAsBytes(), true));
    _changed();
  }

  void _clear() {
    setState(() {
      _items.clear();
      _qrData = null;
      _status = tr('اختر ملفات أو صور أولًا', 'Pick files or photos first', '请先选择文件或照片');
    });
  }

  String _serverBase() => _serverCtrl.text.trim().replaceAll(RegExp(r'/$'), '');

  // Server asks Gemini (key stays on the server). Returns [x, y, w, h] or null.
  Future<List<double>?> _askCrop(Uint8List bytes) async {
    // Disabled: images are never sent to our server. Crop stays on the phone.
    return null;

    try {
      final req = http.MultipartRequest('POST', Uri.parse('${_serverBase()}/crop'))
        ..headers['Authorization'] = 'Bearer ${_token ?? ''}'
        ..files.add(http.MultipartFile.fromBytes(
          'file',
          bytes,
          filename: 'crop.jpg',
          contentType: MediaType('image', 'jpeg'),
        ));
      final streamed = await req.send().timeout(Duration(seconds: 120));
      final body = await streamed.stream.bytesToString();
      final j = jsonDecode(body) as Map<String, dynamic>;
      final box = j['box'];
      if (box is List && box.length == 4) {
        return box.map((e) => (e as num).toDouble()).toList();
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  Uint8List _cropAndEnhance(Uint8List bytes, List<double>? box) {
    var im = img.decodeImage(bytes);
    if (im == null) return bytes;
    if (box != null) {
      final x = (box[0] * im.width).round();
      final y = (box[1] * im.height).round();
      final w = (box[2] * im.width).round();
      final h = (box[3] * im.height).round();
      im = img.copyCrop(im, x: x, y: y, width: w, height: h);
    }
    im = img.normalize(im, min: 0, max: 255);
    return Uint8List.fromList(img.encodeJpg(im, quality: 92));
  }

  String _mimeFor(String name) {
    final ext = name.split('.').last.toLowerCase();
    switch (ext) {
      case 'pdf':
        return 'application/pdf';
      case 'doc':
        return 'application/msword';
      case 'docx':
        return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      case 'png':
        return 'image/png';
      case 'webp':
        return 'image/webp';
      case 'gif':
        return 'image/gif';
      default:
        return 'image/jpeg';
    }
  }

  Future<String> _uploadOne(Uint8List bytes, String name, String mime) async {
    final req = http.MultipartRequest('POST', Uri.parse('${_serverBase()}/upload'))
      ..headers['Authorization'] = 'Bearer ${_token ?? ''}'
      ..files.add(http.MultipartFile.fromBytes(
        'file',
        bytes,
        filename: name,
        contentType: MediaType.parse(mime),
      ));

    final streamed = await req.send().timeout(Duration(seconds: 120));
    final body = await streamed.stream.bytesToString();
    final j = jsonDecode(body) as Map<String, dynamic>;
    if (streamed.statusCode != 200 || j['url'] == null) {
      throw Exception(j['error'] ?? 'HTTP ${streamed.statusCode}');
    }
    return j['url'] as String;
  }

  bool _onceView = false;

  Future<String> _createAlbum(List<String> urls, String? code) async {
    final res = await http.post(
      Uri.parse('${_serverBase()}/album'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${_token ?? ''}',
      },
      body: jsonEncode({'urls': urls, if (code != null) 'code': code, if (_expireSeconds > 0) 'expires_in': _expireSeconds, if (_onceView) 'once': true}),
    ).timeout(Duration(seconds: 60));
    final j = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200 || j['url'] == null) {
      throw Exception(j['error'] ?? 'HTTP ${res.statusCode}');
    }
    return j['url'] as String;
  }

  Future<String> _driveAccessToken() async {
    GoogleSignInAccount? acc = _googleSignIn.currentUser ?? await _googleSignIn.signInSilently();
    if (acc == null) throw Exception('سجّل دخول بحساب Google أولًا');
    final auth = await acc.authentication;
    final t = auth.accessToken;
    if (t == null) throw Exception('ما قدرت أحصل على صلاحية Drive');
    return t;
  }

  // Uploads to the user's own Drive and makes the file readable by link
  Future<String> _driveUpload(Uint8List bytes, String name, String mime, String token) async {
    boundary = 'qrpixboundary';
    final body = BytesBuilder()
      ..add(utf8.encode('--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n'))
      ..add(utf8.encode(jsonEncode({'name': name})))
      ..add(utf8.encode('\r\n--$boundary\r\nContent-Type: $mime\r\n\r\n'))
      ..add(bytes)
      ..add(utf8.encode('\r\n--$boundary--'));
    final res = await http.post(
      Uri.parse('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id'),
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'multipart/related; boundary=$boundary',
      },
      body: body.toBytes(),
    ).timeout(Duration(seconds: 120));
    final j = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200 || j['id'] == null) {
      throw Exception('Drive ${res.statusCode}');
    }
    final id = j['id'] as String;
    await http.post(
      Uri.parse('https://www.googleapis.com/drive/v3/files/$id/permissions'),
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode({'role': 'reader', 'type': 'anyone'}),
    );
    return id;
  }

  Future<void> _generate({bool noCode = false}) async {
    if (_items.isEmpty) {
      _say('اختر ملفًا واحدًا على الأقل');
      return;
    }
    if (_serverBase().isEmpty) {
      _say('رابط السيرفر غير مضبوط');
      return;
    }
    final String? code = noCode ? null : _codeCtrl.text.trim();
    if (code != null && code.length < 4) {
      _say('اكتب رمز فتح من 4 أحرف أو أرقام على الأقل');
      return;
    }

    setState(() => _busy = true);
    try {
      final urls = <String>[];
      final filePass = _filePassCtrl.text;
      String? driveToken;
      try {
        driveToken = await _driveAccessToken();
      } catch (_) {
        driveToken = null;
      }
      if (driveToken == null) {
        throw Exception('سجّل دخول بحساب Google عشان يرفع الملف على Drive الخاص فيك');
      }
      for (var i = 0; i < _items.length; i++) {
        final it = _items[i];
        if (filePass.isNotEmpty) {
          if (driveToken == null) {
            throw Exception('سجّل دخول Google عشان تشفّر الملفات');
          }
          Uint8List raw;
          String mime;
          if (it.isImage) {
            final box = await _askCrop(it.bytes);
            raw = _cropAndEnhance(it.bytes, box);
            mime = 'image/jpeg';
          } else {
            raw = it.bytes;
            mime = _mimeFor(it.name);
          }
          final enc = await _encryptBytes(raw, filePass);
          final id = await _driveUpload(
            enc,
            'qrpix_${DateTime.now().millisecondsSinceEpoch}.enc',
            'application/octet-stream',
            driveToken,
          );
          urls.add('enc|$mime|$id');
          continue;
        }
        _say('رفع ${i + 1} من ${_items.length}...');
        if (it.isImage) {
          final box = await _askCrop(it.bytes);
          final out = _cropAndEnhance(it.bytes, box);
          if (driveToken != null) {
            final id = await _driveUpload(out, 'qrpix_${DateTime.now().millisecondsSinceEpoch}.jpg', 'image/jpeg', driveToken);
            urls.add('https://drive.google.com/thumbnail?id=$id&sz=w1200');
          } else {
            urls.add(await _uploadOne(out, 'qrpix.jpg', 'image/jpeg'));
          }
        } else {
          if (driveToken != null) {
            final id = await _driveUpload(it.bytes, it.name, _mimeFor(it.name), driveToken);
            urls.add('https://drive.google.com/file/d/$id/view');
          } else {
            urls.add(await _uploadOne(it.bytes, it.name, _mimeFor(it.name)));
          }
        }
      }

      _say('إنشاء الألبوم...');
      final albumUrl = await _createAlbum(urls, code);
      if (mounted) {
        setState(() {
          _qrData = albumUrl;
          _status = 'تم. الماسح يطلب الرمز ثم يفتح ${urls.length} ملف';
        });
      }
    } catch (e) {
      _say('خطأ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _fmtTs(num ts) {
    if (ts == 0) return '-';
    final d = DateTime.fromMillisecondsSinceEpoch(ts.toInt() * 1000).toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${d.year}-${two(d.month)}-${two(d.day)} ${two(d.hour)}:${two(d.minute)}';
  }

  Future<void> _loadStats() async {
    setState(() => _busy = true);
    try {
      final res = await http
          .get(
            Uri.parse('${_serverBase()}/stats'),
            headers: {'Authorization': 'Bearer ${_token ?? ''}'},
          )
          .timeout(Duration(seconds: 30));
      final j = jsonDecode(res.body) as Map<String, dynamic>;
      if (res.statusCode != 200) throw Exception(j['error'] ?? 'HTTP ${res.statusCode}');
      final items = (j['items'] as List).cast<Map<String, dynamic>>();
      if (mounted) setState(() => _stats = items);
      _say('تم تحديث الإحصائيات (${items.length} رمز)');
    } catch (e) {
      _say('خطأ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Uint8List _randBytes(int n) {
    final r = Random.secure();
    return Uint8List.fromList(List.generate(n, (_) => r.nextInt(256)));
  }

  // AES-256-GCM with a key derived from the password: output = salt | nonce | ciphertext | tag
  Future<Uint8List> _encryptBytes(Uint8List data, String password) async {
    final salt = _randBytes(16);
    final nonce = _randBytes(12);
    final key = await Pbkdf2(
      macAlgorithm: Hmac.sha256(),
      iterations: 100000,
      bits: 256,
    ).deriveKeyFromPassword(password: password, nonce: salt);
    final box = await AesGcm.with256bits().encrypt(data, secretKey: key, nonce: nonce);
    final out = BytesBuilder()
      ..add(salt)
      ..add(nonce)
      ..add(box.cipherText)
      ..add(box.mac.bytes);
    return out.toBytes();
  }

  String _wifiEsc(String v) => v.replaceAllMapped(RegExp(r'[\\;,:"]'), (m) => '\\${m[0]}');

  void _makeWifi() {
    final ssid = _wifiSsid.text.trim();
    if (ssid.isEmpty) {
      _say('اكتب اسم الشبكة أولًا');
      return;
    }
    final data = _wifiType == 'nopass'
        ? 'WIFI:T:nopass;S:${_wifiEsc(ssid)};;'
        : 'WIFI:T:$_wifiType;S:${_wifiEsc(ssid)};P:${_wifiEsc(_wifiPass.text)};;';
    setState(() => _wifiQr = data);
    _say('تم توليد QR الشبكة');
  }

  void _makeMap() {
    final text = _mapCtrl.text.trim();
    if (text.isEmpty) {
      _say('اكتب رابط الخريطة أو الإحداثيات');
      return;
    }
    String data;
    if (text.startsWith('http')) {
      data = text;
    } else if (RegExp(r'^-?\d+(\.\d+)?\s*,\s*-?\d+(\.\d+)?$').hasMatch(text)) {
      final parts = text.split(',');
      data = 'https://maps.google.com/?q=${parts[0].trim()},${parts[1].trim()}';
    } else {
      data = 'https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(text)}';
    }
    setState(() => _mapQr = data);
    _say('تم توليد QR الموقع');
  }

  Future<void> _openScanner() async {
    final code = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => ScannerPage()),
    );
    if (code == null || !mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(tr('نتيجة المسح', 'Scan result', '扫描结果'), style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            SizedBox(height: 8),
            SelectableText(code),
            SizedBox(height: 12),
            if (code.startsWith('http'))
              FilledButton.icon(
                onPressed: () => launchUrl(Uri.parse(code), mode: LaunchMode.externalApplication),
                icon: Icon(Icons.open_in_new),
                label: Text(tr('فتح الرابط', 'Open link', '打开链接')),
              ),
            OutlinedButton.icon(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: code));
                Navigator.of(ctx).pop();
                _say('تم نسخ النتيجة');
              },
              icon: Icon(Icons.copy),
              label: Text(tr('نسخ', 'Copy', '复制')),
            ),
          ],
        ),
      ),
    );
  }

  Map<String, String> _authJson() => {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${_token ?? ''}',
      };

  Future<Map<String, dynamic>> _callJson(Future<http.Response> Function() f) async {
    final res = await f().timeout(Duration(seconds: 30));
    final j = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200) throw Exception(j['error'] ?? 'HTTP ${res.statusCode}');
    return j;
  }

  Future<void> _dynCreate() async {
    final url = _dynUrlCtrl.text.trim();
    if (!url.startsWith('http')) {
      _say('اكتب رابط يبدأ بـ http');
      return;
    }
    setState(() => _busy = true);
    try {
      final j = await _callJson(() => http.post(
            Uri.parse('${_serverBase()}/dyn'),
            headers: _authJson(),
            body: jsonEncode({'url': url}),
          ));
      if (mounted) setState(() => _dynQr = j['short'] as String);
      _say('تم إنشاء QR المتغيّر');
    } catch (e) {
      _say('خطأ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _dynLoad() async {
    setState(() => _busy = true);
    try {
      final res = await http
          .get(Uri.parse('${_serverBase()}/dyns'), headers: _authJson())
          .timeout(Duration(seconds: 30));
      final j = jsonDecode(res.body) as Map<String, dynamic>;
      if (res.statusCode != 200) throw Exception(j['error'] ?? 'HTTP ${res.statusCode}');
      final items = (j['items'] as List).cast<Map<String, dynamic>>();
      if (mounted) setState(() => _dynList = items);
      _say('عدد رموزك المتغيّرة: ${items.length}');
    } catch (e) {
      _say('خطأ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _dynEdit(String token, String current) async {
    final ctrl = TextEditingController(text: current);
    final newUrl = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('تعديل الرابط'),
        content: TextField(
          controller: ctrl,
          decoration: InputDecoration(labelText: tr('الرابط الجديد', 'New link', '新链接')),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: Text(tr('إلغاء', 'Cancel', '取消'))),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(ctrl.text.trim()),
            child: Text(tr('حفظ', 'Save', '保存')),
          ),
        ],
      ),
    );
    ctrl.dispose();
    if (newUrl == null || newUrl.isEmpty) return;
    if (!newUrl.startsWith('http')) {
      _say('الرابط لازم يبدأ بـ http');
      return;
    }
    try {
      await _callJson(() => http.post(
            Uri.parse('${_serverBase()}/dyn/update'),
            headers: _authJson(),
            body: jsonEncode({'token': token, 'url': newUrl}),
          ));
      _say('تم تحديث الرابط، والـQR نفسه ما يتغيّر');
      _dynLoad();
    } catch (e) {
      _say('خطأ: $e');
    }
  }

  Future<void> _evCreate() async {
    if (_evTitle.text.trim().isEmpty) {
      _say('اكتب عنوان المناسبة');
      return;
    }
    setState(() => _busy = true);
    try {
      final j = await _callJson(() => http.post(
            Uri.parse('${_serverBase()}/event'),
            headers: _authJson(),
            body: jsonEncode({
              'title': _evTitle.text.trim(),
              'date': _evDate.text.trim(),
              'place': _evPlace.text.trim(),
              'note': _evNote.text.trim(),
            }),
          ));
      if (mounted) setState(() => _evQr = j['url'] as String);
      _say('تم إنشاء الدعوة');
    } catch (e) {
      _say('خطأ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _evLoad() async {
    setState(() => _busy = true);
    try {
      final res = await http
          .get(Uri.parse('${_serverBase()}/events'), headers: _authJson())
          .timeout(Duration(seconds: 30));
      final j = jsonDecode(res.body) as Map<String, dynamic>;
      if (res.statusCode != 200) throw Exception(j['error'] ?? 'HTTP ${res.statusCode}');
      final items = (j['items'] as List).cast<Map<String, dynamic>>();
      if (mounted) setState(() => _evList = items);
      _say('عدد الدعوات: ${items.length}');
    } catch (e) {
      _say('خطأ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _saveKey(GlobalKey key, String name) async {
    try {
      final boundary = key.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) {
        _say('تعذر تجهيز الصورة');
        return;
      }
      final image = await boundary.toImage(pixelRatio: 4);
      final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
      if (bytes == null) {
        _say('تعذر تجهيز الصورة');
        return;
      }
      await Gal.putImageBytes(
        bytes.buffer.asUint8List(),
        name: '${name}_${DateTime.now().millisecondsSinceEpoch}.png',
      );
      _say('تم حفظ الصورة في المعرض');
    } catch (e) {
      _say('تعذر الحفظ: $e');
    }
  }

  void _makeCard() {
    String v(TextEditingController c) => c.text.trim().replaceAll(RegExp(r'[\r\n;,]'), ' ');
    final name = v(_cName);
    if (name.isEmpty) {
      _say('اكتب الاسم أولًا');
      return;
    }
    final lines = <String>[
      'BEGIN:VCARD',
      'VERSION:3.0',
      'FN:$name',
      if (v(_cCompany).isNotEmpty) 'ORG:${v(_cCompany)}',
      if (v(_cTitle).isNotEmpty) 'TITLE:${v(_cTitle)}',
      if (v(_cPhone).isNotEmpty) 'TEL;TYPE=CELL:${v(_cPhone)}',
      if (v(_cEmail).isNotEmpty) 'EMAIL:${v(_cEmail)}',
      if (v(_cWeb).isNotEmpty) 'URL:${v(_cWeb)}',
      'END:VCARD',
    ];
    setState(() => _cardData = lines.join('\n'));
    _say('تم توليد البطاقة');
  }

  Future<void> _saveCard() async {
    if (_cardData == null) return;
    try {
      final boundary = _cardKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) {
        _say('تعذر تجهيز البطاقة');
        return;
      }
      final image = await boundary.toImage(pixelRatio: 4);
      final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
      if (bytes == null) {
        _say('تعذر تجهيز البطاقة');
        return;
      }
      await Gal.putImageBytes(
        bytes.buffer.asUint8List(),
        name: 'qr_card_${DateTime.now().millisecondsSinceEpoch}.png',
      );
      _say('تم حفظ البطاقة في المعرض');
    } catch (e) {
      _say('تعذر الحفظ: $e');
    }
  }

  Future<void> _saveQr() async {
    if (_qrData == null) return;
    try {
      final boundary = _qrKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) {
        _say('تعذر تجهيز صورة الـQR');
        return;
      }
      final image = await boundary.toImage(pixelRatio: 4);
      final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
      if (bytes == null) {
        _say('تعذر تجهيز صورة الـQR');
        return;
      }
      await Gal.putImageBytes(
        bytes.buffer.asUint8List(),
        name: 'qr_pix_${DateTime.now().millisecondsSinceEpoch}.png',
      );
      _say('تم حفظ الصورة في المعرض');
    } catch (e) {
      _say('تعذر الحفظ: $e');
    }
  }

  double _clampPos(double v) => v < 0 ? 0 : (v > 184 ? 184 : v);

  Future<void> _pickLogo() async {
    final f = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (f == null) return;
    final bytes = await f.readAsBytes();
    setState(() {
      _logoBytes = bytes;
      _logoPos = Offset(92, 92);
    });
  }

  Widget _section(int number, String title, IconData icon, Widget child) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Color(0xE60B1D3A),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Color(0x33F1D77A)),
        boxShadow: [
          BoxShadow(color: Colors.black38, blurRadius: 16, offset: Offset(0, 6)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 15,
                backgroundColor: Color(0xFFF1D77A),
                child: Text(
                  '$number',
                  style: TextStyle(color: Color(0xFF0B1D3A), fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(width: 10),
              Icon(icon, color: Color(0xFF64B5F6), size: 20),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFFF4F1E6),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 14),
          child,
        ],
      ),
    );
  }

  Widget _loginScreen() {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(child: Image.asset('assets/bg.png', fit: BoxFit.cover)),
          Positioned.fill(child: Container(color: Color(0xE60B1D3A))),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: EdgeInsets.all(20),
                child: Container(
                  constraints: BoxConstraints(maxWidth: 420),
                  padding: EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    color: Color(0xE60B1D3A),
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: Color(0x33F1D77A)),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        'QR PiX',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.w800,
                          color: Color(0xFFF1D77A),
                        ),
                      ),
                      SizedBox(height: 6),
                      Text(
                        tr('سجّل دخولك أو أنشئ حسابًا', 'Sign in or create an account', '登录或创建账户'),
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Color(0xFFB0BEC5)),
                      ),
                      SizedBox(height: 18),
                      _field(_emailCtrl, tr('البريد الإلكتروني', 'Email', '邮箱'), Icons.email_outlined),
                      _field(_passCtrl, tr('كلمة السر (6 أحرف أو أكثر)', 'Password (6+ characters)', '密码（至少 6 位）'), Icons.lock_outline, obscure: true),
                      SizedBox(height: 6),
                      FilledButton(
                        style: _btnStyle,
                        onPressed: _busy ? null : () => _auth('login'),
                        child: Text(_busy ? tr('جاري التحقق...', 'Verifying...', '正在验证...') : tr('تسجيل الدخول', 'Sign in', '登录')),
                      ),
                      SizedBox(height: 10),
                      OutlinedButton(
                        onPressed: _busy ? null : () => _auth('register'),
                        child: Text(tr('إنشاء حساب جديد', 'Create new account', '创建新账户')),
                      ),
                      SizedBox(height: 10),
                      FilledButton.icon(
                        style: FilledButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: Colors.black87,
                          minimumSize: Size.fromHeight(50),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        onPressed: _busy ? null : _googleLogin,
                        icon: Text('G', style: TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF4285F4), fontSize: 18)),
                        label: Text(tr('المتابعة باستخدام Google', 'Continue with Google', '使用 Google 继续')),
                      ),
                      SizedBox(height: 14),
                      Text(
                        _status,
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Color(0xFFFF8A80)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _field(TextEditingController c, String label, IconData icon, {bool obscure = false}) {
    return Padding(
      padding: EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: c,
        obscureText: obscure,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon, size: 20),
          filled: true,
          fillColor: Color(0xFF0B1D3A),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: Color(0x33F1D77A)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: Color(0xFFF1D77A)),
          ),
        ),
      ),
    );
  }

  ButtonStyle get _btnStyle => FilledButton.styleFrom(
        minimumSize: Size.fromHeight(50),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        textStyle: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
      );

  Widget _filesPreview() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final it in _items)
          it.isImage
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.memory(it.bytes, width: 76, height: 76, fit: BoxFit.cover),
                )
              : Container(
                  width: 76,
                  height: 76,
                  padding: EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: Color(0xFF13294F),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.picture_as_pdf, color: Color(0xFFF1D77A)),
                      SizedBox(height: 4),
                      Text(
                        it.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 10),
                      ),
                    ],
                  ),
                ),
      ],
    );
  }

  Widget _statusBar() {
    final isError = _status.startsWith('خطأ') || _status.startsWith('تعذر');
    final isOk = _status.startsWith('تم');
    final color = isError
        ? Color(0xFFFF8A80)
        : isOk
            ? Color(0xFF81C784)
            : Color(0xFFB0BEC5);
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Row(
        children: [
          Icon(
            isError ? Icons.error_outline : (isOk ? Icons.check_circle_outline : Icons.info_outline),
            color: color,
            size: 20,
          ),
          SizedBox(width: 8),
          Expanded(child: Text(_status, style: TextStyle(color: color))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_token == null) return _loginScreen();
    return Scaffold(
      extendBodyBehindAppBar: false,
      appBar: AppBar(
        backgroundColor: Color(0xFF0B1D3A),
        elevation: 0,
        centerTitle: true,
        actions: [
          IconButton(
            tooltip: 'حجم الخط',
            onPressed: _openFontSheet,
            icon: Icon(Icons.text_fields),
          ),
          IconButton(
            tooltip: tr('تسجيل الخروج', 'Sign out', '退出登录'),
            onPressed: _logout,
            icon: Icon(Icons.logout),
          ),
        ],
        title: Text(
          'QR PiX',
          style: TextStyle(
            fontWeight: FontWeight.w800,
            letterSpacing: 1.2,
            color: Color(0xFFF1D77A),
          ),
        ),
      ),
      body: Stack(
        children: [
          Positioned.fill(child: Image.asset('assets/bg.png', fit: BoxFit.cover)),
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xB30B1D3A), Color(0xF20B1D3A)],
                ),
              ),
            ),
          ),
          SafeArea(
            child: ListView(
              padding: EdgeInsets.fromLTRB(16, 16, 16, 28),
              children: [
                _section(
                  1,
                  tr('الملفات', 'Files', '文件'),
                  Icons.folder_open,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: FilledButton.icon(
                              style: _btnStyle,
                              onPressed: _busy ? null : _openGallery,
                              icon: Icon(Icons.photo_library),
                              label: Text(tr('معرض الصور', 'Gallery', '相册')),
                            ),
                          ),
                          SizedBox(width: 10),
                          Expanded(
                            child: FilledButton.tonalIcon(
                              style: _btnStyle,
                              onPressed: _busy ? null : _pickCamera,
                              icon: Icon(Icons.camera_alt),
                              label: Text(tr('كاميرا', 'Camera', '相机')),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      OutlinedButton.icon(
                        style: _btnStyle,
                        onPressed: _busy ? null : _pickFiles,
                        icon: Icon(Icons.picture_as_pdf),
                        label: Text(tr('ملفات PDF', 'PDF files', 'PDF 文件')),
                      ),
                      SizedBox(height: 10),
                      if (_items.isNotEmpty) ...[
                        SizedBox(height: 14),
                        _filesPreview(),
                        SizedBox(height: 6),
                        Align(
                          alignment: AlignmentDirectional.centerEnd,
                          child: TextButton.icon(
                            onPressed: _busy ? null : _clear,
                            icon: Icon(Icons.delete_outline, size: 18),
                            label: Text(tr('مسح الكل', 'Clear all', '全部清除')),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                _section(
                  2,
                  tr('رمز فتح الألبوم', 'Album unlock code', '相册解锁码'),
                  Icons.lock_outline,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                  _field(_codeCtrl, tr('الرمز (4 أحرف أو أرقام أو أكثر)', 'Code (4+ letters or digits)', '密码（4位以上字母或数字）'), Icons.password),
                  DropdownButtonFormField<int>(
                    initialValue: _expireSeconds,
                    decoration: InputDecoration(
                      labelText: tr('مدة صلاحية الرمز', 'Code validity', '密码有效期'),
                      border: OutlineInputBorder(),
                    ),
                    items: [
                      DropdownMenuItem(value: 0, child: Text(tr('بدون انتهاء', 'No expiry', '永不过期'))),
                      DropdownMenuItem(value: 3600, child: Text(tr('ساعة واحدة', '1 hour', '1 小时'))),
                      DropdownMenuItem(value: 86400, child: Text(tr('يوم واحد', '1 day', '1 天'))),
                      DropdownMenuItem(value: 604800, child: Text(tr('أسبوع', '1 week', '1 周'))),
                    ],
                    onChanged: (v) => setState(() => _expireSeconds = v ?? 0),
                  ),
                  SizedBox(height: 12),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(tr('يفتح مرة وحدة فقط', 'Open only once', '仅可打开一次')),
                    value: _onceView,
                    onChanged: (v) => setState(() => _onceView = v),
                  ),
                  _field(_filePassCtrl, tr('كلمة مرور الملفات (اختياري، منفصلة)', 'File password (optional, separate)', '文件密码（可选，单独设置）'), Icons.enhanced_encryption, obscure: true),
                    ],
                  ),
                ),
                _section(
                  3,
                  tr('رمز QR', 'QR code', '二维码'),
                  Icons.qr_code_2,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      FilledButton.icon(
                        style: _btnStyle,
                        onPressed: _busy ? null : _generate,
                        icon: _busy
                            ? SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : Icon(Icons.auto_awesome),
                        label: Text(_busy ? tr('جاري العمل...', 'Working...', '处理中...') : tr('توليد QR', 'Generate QR', '生成二维码')),
                      ),
                      SizedBox(height: 12),
                      _statusBar(),
                      if (_qrData != null) ...[
                        SizedBox(height: 16),
                        Wrap(
                          spacing: 10,
                          runSpacing: 10,
                          alignment: WrapAlignment.center,
                          children: [
                            for (final c in [
                              Color(0xFF0B1D3A),
                              Color(0xFF000000),
                              Color(0xFF1B5E20),
                              Color(0xFF6A1B9A),
                              Color(0xFFB71C1C),
                            ])
                              GestureDetector(
                                onTap: () => setState(() => _qrColor = c),
                                child: CircleAvatar(
                                  radius: 14,
                                  backgroundColor: c,
                                  child: _qrColor == c
                                      ? Icon(Icons.check, color: Colors.white, size: 16)
                                      : null,
                                ),
                              ),
                          ],
                        ),
                        SizedBox(height: 10),
                        Wrap(
                          spacing: 8,
                          alignment: WrapAlignment.center,
                          children: [
                            OutlinedButton.icon(
                              onPressed: _pickLogo,
                              icon: Icon(Icons.image_outlined),
                              label: Text(tr('إضافة شعار', 'Add logo', '添加 logo')),
                            ),
                            if (_logoBytes != null)
                              TextButton(
                                onPressed: () => setState(() => _logoBytes = null),
                                child: Text(tr('إزالة الشعار', 'Remove logo', '移除 logo')),
                              ),
                          ],
                        ),
                        SizedBox(height: 12),
                        Center(
                          child: RepaintBoundary(
                            key: _qrKey,
                            child: Container(
                              padding: EdgeInsets.all(14),
                              color: Colors.white,
                              child: SizedBox(
                                width: 240,
                                height: 240,
                                child: Stack(
                                  children: [
                                    QrImageView(
                                      data: _qrData!,
                                      size: 240,
                                      errorCorrectionLevel: qr.QrErrorCorrectLevel.H,
                                      eyeStyle: QrEyeStyle(eyeShape: QrEyeShape.square, color: _qrColor),
                                      dataModuleStyle: QrDataModuleStyle(
                                        dataModuleShape: QrDataModuleShape.square,
                                        color: _qrColor,
                                      ),
                                    ),
                                    if (_logoBytes != null)
                                      Positioned(
                                        left: _logoPos.dx,
                                        top: _logoPos.dy,
                                        child: GestureDetector(
                                          onPanUpdate: (d) => setState(() {
                                            _logoPos = Offset(
                                              _clampPos(_logoPos.dx + d.delta.dx),
                                              _clampPos(_logoPos.dy + d.delta.dy),
                                            );
                                          }),
                                          child: ClipRRect(
                                            borderRadius: BorderRadius.circular(8),
                                            child: Image.memory(
                                              _logoBytes!,
                                              width: 56,
                                              height: 56,
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 12),
                        FilledButton.icon(
                          style: _btnStyle,
                          onPressed: _saveQr,
                          icon: Icon(Icons.download),
                          label: Text(tr('حفظ الـQR في المعرض', 'Save QR to gallery', '保存二维码到相册')),
                        ),
                        SizedBox(height: 8),
                        OutlinedButton.icon(
                          onPressed: _exportPdf,
                          icon: Icon(Icons.picture_as_pdf),
                          label: Text(tr('تصدير PDF للطباعة', 'Export PDF for printing', '导出 PDF 用于打印')),
                        ),
                        SizedBox(height: 10),
                        FilledButton.tonalIcon(
                          style: _btnStyle,
                          onPressed: _openAlbum,
                          icon: Icon(Icons.open_in_new),
                          label: Text('فتح الألبوم هنا'),
                        ),
                        SizedBox(height: 10),
                        SelectableText(
                          _qrData!,
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 12, color: Color(0xFFB0BEC5)),
                        ),
                      ],
                    ],
                  ),
                ),
          if (_batchCount > 0)
          _section(
            5,
            'QR جماعي (حتى 500)',
            Icons.grid_view,
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  _batchCount == 0
                      ? 'اختر ملف Excel أو CSV من القسم 1 أولاً'
                      : 'الروابط الجاهزة من الملف',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: Color(0xFFB0BEC5)),
                ),
                if (_batchCount > 0) ...[
                  SizedBox(height: 8),
                  Text('عدد الروابط: $_batchCount', textAlign: TextAlign.center),
                  SizedBox(height: 10),
                  FilledButton.icon(
                    style: _btnStyle,
                    onPressed: _busy ? null : _makeBatchZip,
                    icon: Icon(Icons.archive),
                    label: Text('إنشاء ZIP وحفظه'),
                  ),
                ],
              ],
            ),
          ),
          _section(
            6,
            tr('بطاقة QR شخصية', 'Personal QR card', '个人二维码名片'),
            Icons.badge,
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _field(_cName, tr('الاسم', 'Name', '姓名'), Icons.person),
                _field(_cTitle, tr('الوظيفة', 'Job title', '职位'), Icons.work_outline),
                _field(_cCompany, tr('الشركة', 'Company', '公司'), Icons.business),
                _field(_cPhone, tr('رقم الهاتف', 'Phone', '电话'), Icons.phone),
                _field(_cEmail, tr('الإيميل', 'Email', '邮箱'), Icons.email_outlined),
                _field(_cWeb, tr('الموقع أو رابط التواصل', 'Website or social link', '网站或社交链接'), Icons.link),
                FilledButton.icon(
                  style: _btnStyle,
                  onPressed: _makeCard,
                  icon: Icon(Icons.badge),
                  label: Text(tr('توليد بطاقة QR', 'Generate card QR', '生成名片二维码')),
                ),
                if (_cardData != null) ...[
                  SizedBox(height: 12),
                  Center(
                    child: RepaintBoundary(
                      key: _cardKey,
                      child: Container(
                        padding: EdgeInsets.all(14),
                        color: Colors.white,
                        child: QrImageView(
                          data: _cardData!,
                          size: 220,
                          errorCorrectionLevel: qr.QrErrorCorrectLevel.M,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 10),
                  FilledButton.icon(
                    style: _btnStyle,
                    onPressed: _saveCard,
                    icon: Icon(Icons.download),
                    label: Text(tr('حفظ البطاقة في المعرض', 'Save card to gallery', '保存名片到相册')),
                  ),
                ],
              ],
            ),
          ),
          _section(
            7,
            tr('إحصائيات QR', 'QR statistics', '二维码统计'),
            Icons.bar_chart,
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                FilledButton.icon(
                  style: _btnStyle,
                  onPressed: _busy ? null : _loadStats,
                  icon: Icon(Icons.refresh),
                  label: Text(tr('تحديث الإحصائيات', 'Refresh stats', '刷新统计')),
                ),
                SizedBox(height: 10),
                for (final st in _stats)
                  Container(
                    margin: EdgeInsets.only(bottom: 8),
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Color(0xFF13294F),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('تاريخ الإنشاء: ${_fmtTs(st['created'] ?? 0)}'),
                        Text('عدد الملفات: ${st['count'] ?? 0}'),
                        Text(
                          'عدد المسحات: ${st['views'] ?? 0}',
                          style: TextStyle(color: Color(0xFFF1D77A), fontWeight: FontWeight.bold),
                        ),
                        Text(
                          'آخر مسح: ${((st['last_views'] as List?) ?? []).isNotEmpty ? _fmtTs(((st['last_views'] as List).first) as num) : '-'}',
                        ),
                        Text(st['exp'] == null ? tr('بدون انتهاء', 'No expiry', '永不过期') : 'تنتهي: ${_fmtTs(st['exp'] as num)}'),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          _section(
            8,
            tr('أدوات سريعة', 'Quick tools', '快捷工具'),
            Icons.build_circle_outlined,
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                FilledButton.icon(
                  style: _btnStyle,
                  onPressed: _openScanner,
                  icon: Icon(Icons.qr_code_scanner),
                  label: Text(tr('ماسح QR', 'QR scanner', '二维码扫描')),
                ),
                SizedBox(height: 16),
                Text(tr('QR شبكة Wi-Fi', 'Wi-Fi QR', 'Wi-Fi 二维码'), style: TextStyle(fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                _field(_wifiSsid, tr('اسم الشبكة (SSID)', 'Network name (SSID)', '网络名称（SSID）'), Icons.wifi),
                _field(_wifiPass, tr('كلمة مرور الشبكة', 'Network password', '网络密码'), Icons.key, obscure: true),
                DropdownButtonFormField<String>(
                  initialValue: _wifiType,
                  decoration: InputDecoration(
                    labelText: tr('نوع الحماية', 'Security type', '加密类型'),
                    border: OutlineInputBorder(),
                  ),
                  items: [
                    DropdownMenuItem(value: 'WPA', child: Text('WPA / WPA2')),
                    DropdownMenuItem(value: 'WEP', child: Text('WEP')),
                    DropdownMenuItem(value: 'nopass', child: Text(tr('بدون كلمة مرور', 'No password', '无密码'))),
                  ],
                  onChanged: (v) => setState(() => _wifiType = v ?? 'WPA'),
                ),
                SizedBox(height: 10),
                FilledButton.icon(
                  style: _btnStyle,
                  onPressed: _makeWifi,
                  icon: Icon(Icons.wifi),
                  label: Text(tr('توليد QR الشبكة', 'Generate Wi-Fi QR', '生成 Wi-Fi 二维码')),
                ),
                if (_wifiQr != null) ...[
                  SizedBox(height: 10),
                  Center(
                    child: RepaintBoundary(
                      key: _wifiKey,
                      child: Container(
                        padding: EdgeInsets.all(14),
                        color: Colors.white,
                        child: QrImageView(data: _wifiQr!, size: 200),
                      ),
                    ),
                  ),
                  SizedBox(height: 8),
                  FilledButton.icon(
                    style: _btnStyle,
                    onPressed: () => _saveKey(_wifiKey, 'wifi'),
                    icon: Icon(Icons.download),
                    label: Text(tr('حفظ QR الشبكة', 'Save Wi-Fi QR', '保存 Wi-Fi 二维码')),
                  ),
                ],
                SizedBox(height: 16),
                Text(tr('QR موقع على الخريطة', 'Map location QR', '地图位置二维码'), style: TextStyle(fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                _field(_mapCtrl, tr('رابط خرائط أو إحداثيات (lat,lng)', 'Map link or coordinates (lat,lng)', '地图链接或坐标（lat,lng）'), Icons.map),
                FilledButton.icon(
                  style: _btnStyle,
                  onPressed: _makeMap,
                  icon: Icon(Icons.place),
                  label: Text(tr('توليد QR الموقع', 'Generate location QR', '生成位置二维码')),
                ),
                if (_mapQr != null) ...[
                  SizedBox(height: 10),
                  Center(
                    child: RepaintBoundary(
                      key: _mapKey,
                      child: Container(
                        padding: EdgeInsets.all(14),
                        color: Colors.white,
                        child: QrImageView(data: _mapQr!, size: 200),
                      ),
                    ),
                  ),
                  SizedBox(height: 8),
                  FilledButton.icon(
                    style: _btnStyle,
                    onPressed: () => _saveKey(_mapKey, 'map'),
                    icon: Icon(Icons.download),
                    label: Text(tr('حفظ QR الموقع', 'Save location QR', '保存位置二维码')),
                  ),
                ],
              ],
            ),
          ),
          _section(
            9,
            tr('QR متغيّر', 'Dynamic QR', '动态二维码'),
            Icons.autorenew,
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'الرمز يفتح رابط قصير، وتقدر تغيّر الوجهة بعد الطباعة بدون ما تغيّر الرمز.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: Color(0xFFB0BEC5)),
                ),
                SizedBox(height: 10),
                _field(_dynUrlCtrl, tr('الرابط اللي يفتحه الرمز', 'Link this QR opens', '二维码打开的链接'), Icons.link),
                FilledButton.icon(
                  style: _btnStyle,
                  onPressed: _busy ? null : _dynCreate,
                  icon: Icon(Icons.autorenew),
                  label: Text(tr('إنشاء QR متغيّر', 'Create dynamic QR', '创建动态二维码')),
                ),
                if (_dynQr != null) ...[
                  SizedBox(height: 10),
                  Center(
                    child: RepaintBoundary(
                      key: _dynKey,
                      child: Container(
                        padding: EdgeInsets.all(14),
                        color: Colors.white,
                        child: QrImageView(data: _dynQr!, size: 200),
                      ),
                    ),
                  ),
                  SizedBox(height: 8),
                  FilledButton.icon(
                    style: _btnStyle,
                    onPressed: () => _saveKey(_dynKey, 'dynamic_qr'),
                    icon: Icon(Icons.download),
                    label: Text(tr('حفظ QR المتغيّر', 'Save dynamic QR', '保存动态二维码')),
                  ),
                ],
                SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: _busy ? null : _dynLoad,
                  icon: Icon(Icons.refresh),
                  label: Text(tr('تحديث قائمة رموزي المتغيّرة', 'Refresh my dynamic QRs', '刷新我的动态二维码')),
                ),
                for (final d in _dynList)
                  Container(
                    margin: EdgeInsets.only(top: 8),
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Color(0xFF13294F),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('الوجهة: ${d['url']}', style: TextStyle(fontSize: 12)),
                        Text(
                          'عدد المسحات: ${d['scans'] ?? 0}',
                          style: TextStyle(color: Color(0xFFF1D77A), fontWeight: FontWeight.bold),
                        ),
                        TextButton(
                          onPressed: () => _dynEdit(d['token'] as String, d['url'] as String),
                          child: Text(tr('تعديل الوجهة', 'Edit destination', '修改目的地')),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          _section(
            10,
            tr('دعوات ومناسبات', 'Invitations & events', '邀请函与活动'),
            Icons.celebration,
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _field(_evTitle, tr('عنوان المناسبة', 'Event title', '活动标题'), Icons.event),
                _field(_evDate, tr('التاريخ والوقت', 'Date & time', '日期和时间'), Icons.calendar_today),
                _field(_evPlace, tr('المكان', 'Place', '地点'), Icons.place),
                _field(_evNote, tr('ملاحظة (اختياري)', 'Note (optional)', '备注（可选）'), Icons.notes),
                FilledButton.icon(
                  style: _btnStyle,
                  onPressed: _busy ? null : _evCreate,
                  icon: Icon(Icons.celebration),
                  label: Text(tr('إنشاء الدعوة', 'Create invitation', '创建邀请')),
                ),
                if (_evQr != null) ...[
                  SizedBox(height: 10),
                  Center(
                    child: RepaintBoundary(
                      key: _evKey,
                      child: Container(
                        padding: EdgeInsets.all(14),
                        color: Colors.white,
                        child: QrImageView(data: _evQr!, size: 200),
                      ),
                    ),
                  ),
                  SizedBox(height: 8),
                  FilledButton.icon(
                    style: _btnStyle,
                    onPressed: () => _saveKey(_evKey, 'invitation'),
                    icon: Icon(Icons.download),
                    label: Text(tr('حفظ QR الدعوة', 'Save invitation QR', '保存邀请二维码')),
                  ),
                ],
                SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: _busy ? null : _evLoad,
                  icon: Icon(Icons.refresh),
                  label: Text(tr('تحديث قائمة الحضور', 'Refresh attendance', '刷新出席名单')),
                ),
                for (final ev in _evList)
                  Container(
                    margin: EdgeInsets.only(top: 8),
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Color(0xFF13294F),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${ev['title']}',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Text('التاريخ: ${ev['date'] ?? ''}'),
                        Text('المكان: ${ev['place'] ?? ''}'),
                        Text(
                          'المؤكدون: ${ev['rsvps'] ?? 0} | عدد الحضور: ${ev['guests'] ?? 0}',
                          style: TextStyle(color: Color(0xFFF1D77A), fontWeight: FontWeight.bold),
                        ),
                        Text(
                          'الأسماء: ${((ev['names'] as List?) ?? []).join('، ')}',
                          style: TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          _section(
            11,
            tr('قائمة المطعم', 'Restaurant menu', '餐厅菜单'),
            Icons.restaurant_menu,
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'اختر الصور أو ملفات PDF للمنيو من القسم 1، ثم اضغط الزر لإنشاء QR بدون رمز.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: Color(0xFFB0BEC5)),
                ),
                SizedBox(height: 10),
                FilledButton.icon(
                  style: _btnStyle,
                  onPressed: _busy ? null : () => _generate(noCode: true),
                  icon: Icon(Icons.restaurant_menu),
                  label: Text(tr('إنشاء QR المنيو (بدون رمز)', 'Create menu QR (no code)', '创建菜单二维码（无密码）')),
                ),
              ],
            ),
          ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ScannerPage extends StatefulWidget {
  ScannerPage({super.key});

  @override
  State<ScannerPage> createState() => _ScannerPageState();
}

class _ScannerPageState extends State<ScannerPage> {
  bool _done = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('ماسح QR', 'QR scanner', '二维码扫描'))),
      body: MobileScanner(
        onDetect: (capture) {
          if (_done) return;
          if (capture.barcodes.isEmpty) return;
          final code = capture.barcodes.first.rawValue;
          if (code == null || code.isEmpty) return;
          _done = true;
          Navigator.of(context).pop(code);
        },
      ),
    );
  }
}

class AlbumPage extends StatefulWidget {
  final String url;
  AlbumPage({super.key, required this.url});

  @override
  State<AlbumPage> createState() => _AlbumPageState();
}

class _AlbumPageState extends State<AlbumPage> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onNavigationRequest: (request) {
            final uri = Uri.parse(request.url);
            final isWeb = uri.scheme == 'http' || uri.scheme == 'https';
            if (isWeb && uri.host == 'drive.google.com' && uri.path.startsWith('/thumbnail')) {
              _saveImage(uri);
              return NavigationDecision.prevent;
            }
            if (isWeb && uri.host != 't.me' && uri.host != 'telegram.me') {
              return NavigationDecision.navigate;
            }
            // Telegram links and other app schemes open outside the WebView
            launchUrl(uri, mode: LaunchMode.externalApplication);
            return NavigationDecision.prevent;
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.url));
  }

  Future<void> _saveImage(Uri uri) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      final res = await http.get(uri);
      if (res.statusCode != 200) throw Exception('HTTP ${res.statusCode}');
      await Gal.putImageBytes(
        res.bodyBytes,
        name: 'qr_pix_${DateTime.now().millisecondsSinceEpoch}.jpg',
      );
      messenger.showSnackBar(SnackBar(content: Text('تم حفظ الصورة في المعرض')));
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('تعذر الحفظ: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('الألبوم'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(10),
            color: Color(0xFF13294F),
            child: Text(
              tr('اضغط على أي صورة لحفظها في جوالك', 'Tap any image to save it to your phone', '点击任意图片即可保存到手机'),
              textAlign: TextAlign.center,
              style: TextStyle(color: Color(0xFFF1D77A)),
            ),
          ),
          Expanded(child: WebViewWidget(controller: _controller)),
        ],
      ),
    );
  }
}
