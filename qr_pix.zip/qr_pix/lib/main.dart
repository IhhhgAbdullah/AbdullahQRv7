import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() => runApp(const QrPixApp());

class QrPixApp extends StatelessWidget {
  const QrPixApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QR PiX',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorSchemeSeed: const Color(0xFF1E88E5),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class PickedItem {
  final String name;
  final Uint8List bytes;
  final bool isImage;
  PickedItem(this.name, this.bytes, this.isImage);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _serverCtrl = TextEditingController();
  final _keyCtrl = TextEditingController();
  final _codeCtrl = TextEditingController();
  final _picker = ImagePicker();

  final List<PickedItem> _items = [];
  String? _qrData;
  String _status = 'اختر الملفات';
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  @override
  void dispose() {
    _serverCtrl.dispose();
    _keyCtrl.dispose();
    _codeCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadSettings() async {
    final p = await SharedPreferences.getInstance();
    _serverCtrl.text = p.getString('server') ?? '';
    _keyCtrl.text = p.getString('upkey') ?? '';
  }

  Future<void> _saveSettings() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('server', _serverCtrl.text.trim());
    await p.setString('upkey', _keyCtrl.text.trim());
    _say('تم حفظ الإعدادات');
  }

  void _say(String s) {
    if (mounted) setState(() => _status = s);
  }

  void _changed() {
    setState(() {
      _qrData = null;
      _status = 'عدد الملفات: ${_items.length}';
    });
  }

  Future<void> _pickFiles() async {
    const group = XTypeGroup(
      label: 'PDF والصور',
      extensions: ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'gif'],
    );
    final files = await openFiles(acceptedTypeGroups: [group]);
    for (final f in files) {
      final bytes = await f.readAsBytes();
      final ext = f.name.split('.').last.toLowerCase();
      final isImage = ['jpg', 'jpeg', 'png', 'webp', 'gif'].contains(ext);
      _items.add(PickedItem(f.name, bytes, isImage));
    }
    _changed();
  }

  Future<void> _pickCamera() async {
    final f = await _picker.pickImage(source: ImageSource.camera, imageQuality: 100);
    if (f == null) return;
    _items.add(PickedItem(f.name, await f.readAsBytes(), true));
    _changed();
  }

  void _clear() {
    setState(() {
      _items.clear();
      _qrData = null;
      _status = 'اختر الملفات';
    });
  }

  String _serverBase() => _serverCtrl.text.trim().replaceAll(RegExp(r'/$'), '');

  // Server asks Gemini (key stays on the server). Returns [x, y, w, h] or null.
  Future<List<double>?> _askCrop(Uint8List bytes) async {
    try {
      final req = http.MultipartRequest('POST', Uri.parse('${_serverBase()}/crop'))
        ..headers['X-Upload-Key'] = _keyCtrl.text.trim()
        ..files.add(http.MultipartFile.fromBytes(
          'file',
          bytes,
          filename: 'crop.jpg',
          contentType: MediaType('image', 'jpeg'),
        ));
      final streamed = await req.send();
      final body = await streamed.stream.bytesToString();
      final j = jsonDecode(body) as Map<String, dynamic>;
      final box = j['box'];
      if (box is List && box.length == 4) {
        return box.map((e) => (e as num).toDouble()).toList();
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  Uint8List _cropAndEnhance(Uint8List bytes, List<double>? box) {
    var im = img.decodeImage(bytes);
    if (im == null) return bytes;
    if (box != null) {
      final x = (box[0] * im.width).round();
      final y = (box[1] * im.height).round();
      final w = (box[2] * im.width).round();
      final h = (box[3] * im.height).round();
      im = img.copyCrop(im, x: x, y: y, width: w, height: h);
    }
    im = img.normalize(im, min: 0, max: 255);
    return Uint8List.fromList(img.encodeJpg(im, quality: 92));
  }

  String _mimeFor(String name) {
    final ext = name.split('.').last.toLowerCase();
    switch (ext) {
      case 'pdf':
        return 'application/pdf';
      case 'doc':
        return 'application/msword';
      case 'docx':
        return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      case 'png':
        return 'image/png';
      case 'webp':
        return 'image/webp';
      case 'gif':
        return 'image/gif';
      default:
        return 'image/jpeg';
    }
  }

  Future<String> _uploadOne(Uint8List bytes, String name, String mime) async {
    final req = http.MultipartRequest('POST', Uri.parse('${_serverBase()}/upload'))
      ..headers['X-Upload-Key'] = _keyCtrl.text.trim()
      ..files.add(http.MultipartFile.fromBytes(
        'file',
        bytes,
        filename: name,
        contentType: MediaType.parse(mime),
      ));

    final streamed = await req.send();
    final body = await streamed.stream.bytesToString();
    final j = jsonDecode(body) as Map<String, dynamic>;
    if (streamed.statusCode != 200 || j['url'] == null) {
      throw Exception(j['error'] ?? 'HTTP ${streamed.statusCode}');
    }
    return j['url'] as String;
  }

  Future<String> _createAlbum(List<String> urls, String code) async {
    final res = await http.post(
      Uri.parse('${_serverBase()}/album'),
      headers: {
        'Content-Type': 'application/json',
        'X-Upload-Key': _keyCtrl.text.trim(),
      },
      body: jsonEncode({'urls': urls, 'code': code}),
    );
    final j = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200 || j['url'] == null) {
      throw Exception(j['error'] ?? 'HTTP ${res.statusCode}');
    }
    return j['url'] as String;
  }

  Future<void> _generate() async {
    if (_items.isEmpty) {
      _say('اختر ملفًا واحدًا على الأقل');
      return;
    }
    if (_serverBase().isEmpty || _keyCtrl.text.trim().isEmpty) {
      _say('أدخل رابط السيرفر ومفتاح الرفع أولًا');
      return;
    }
    final code = _codeCtrl.text.trim();
    if (code.length < 4) {
      _say('اكتب رمز فتح من 4 أحرف أو أرقام على الأقل');
      return;
    }

    setState(() => _busy = true);
    try {
      final urls = <String>[];
      for (var i = 0; i < _items.length; i++) {
        final it = _items[i];
        _say('رفع ${i + 1} من ${_items.length}...');
        if (it.isImage) {
          final box = await _askCrop(it.bytes);
          final out = _cropAndEnhance(it.bytes, box);
          urls.add(await _uploadOne(out, 'qrpix.jpg', 'image/jpeg'));
        } else {
          urls.add(await _uploadOne(it.bytes, it.name, _mimeFor(it.name)));
        }
      }

      _say('إنشاء الألبوم...');
      final albumUrl = await _createAlbum(urls, code);
      if (mounted) {
        setState(() {
          _qrData = albumUrl;
          _status = 'تم. الماسح يطلب الرمز ثم يفتح ${urls.length} ملف';
        });
      }
    } catch (e) {
      _say('خطأ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _saveQr() async {
    final url = _qrData;
    if (url == null) return;
    try {
      const double size = 900;
      final painter = QrPainter(data: url, version: QrVersions.auto, gapless: true);
      final recorder = ui.PictureRecorder();
      final canvas = ui.Canvas(recorder, ui.Rect.fromLTWH(0, 0, size, size));
      canvas.drawRect(
        ui.Rect.fromLTWH(0, 0, size, size),
        ui.Paint()..color = Colors.white,
      );
      painter.paint(canvas, const Size(size, size));
      final picture = recorder.endRecording();
      final image = await picture.toImage(size.toInt(), size.toInt());
      final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
      if (bytes == null) {
        _say('تعذر تجهيز صورة الـQR');
        return;
      }
      await Gal.putImageBytes(
        bytes.buffer.asUint8List(),
        name: 'qr_pix_${DateTime.now().millisecondsSinceEpoch}.png',
      );
      _say('تم حفظ الـQR في المعرض');
    } catch (e) {
      _say('تعذر الحفظ: $e');
    }
  }

  Widget _section(int number, String title, IconData icon, Widget child) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xE60B1D3A),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0x33F1D77A)),
        boxShadow: const [
          BoxShadow(color: Colors.black38, blurRadius: 16, offset: Offset(0, 6)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 15,
                backgroundColor: const Color(0xFFF1D77A),
                child: Text(
                  '$number',
                  style: const TextStyle(color: Color(0xFF0B1D3A), fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(width: 10),
              Icon(icon, color: const Color(0xFF64B5F6), size: 20),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFFF4F1E6),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }

  Widget _field(TextEditingController c, String label, IconData icon, {bool obscure = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: c,
        obscureText: obscure,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon, size: 20),
          filled: true,
          fillColor: const Color(0xFF0B1D3A),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0x33F1D77A)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFF1D77A)),
          ),
        ),
      ),
    );
  }

  ButtonStyle get _btnStyle => FilledButton.styleFrom(
        minimumSize: const Size.fromHeight(50),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
      );

  Widget _filesPreview() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final it in _items)
          it.isImage
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.memory(it.bytes, width: 76, height: 76, fit: BoxFit.cover),
                )
              : Container(
                  width: 76,
                  height: 76,
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF13294F),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.picture_as_pdf, color: Color(0xFFF1D77A)),
                      const SizedBox(height: 4),
                      Text(
                        it.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 10),
                      ),
                    ],
                  ),
                ),
      ],
    );
  }

  Widget _statusBar() {
    final isError = _status.startsWith('خطأ') || _status.startsWith('تعذر');
    final isOk = _status.startsWith('تم');
    final color = isError
        ? const Color(0xFFFF8A80)
        : isOk
            ? const Color(0xFF81C784)
            : const Color(0xFFB0BEC5);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Row(
        children: [
          Icon(
            isError ? Icons.error_outline : (isOk ? Icons.check_circle_outline : Icons.info_outline),
            color: color,
            size: 20,
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(_status, style: TextStyle(color: color))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: const Text(
          'QR PiX',
          style: TextStyle(
            fontWeight: FontWeight.w800,
            letterSpacing: 1.2,
            color: Color(0xFFF1D77A),
          ),
        ),
      ),
      body: Stack(
        children: [
          Positioned.fill(child: Image.asset('assets/bg.png', fit: BoxFit.cover)),
          const Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xB30B1D3A), Color(0xF20B1D3A)],
                ),
              ),
            ),
          ),
          SafeArea(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 56, 16, 28),
              children: [
                _section(
                  1,
                  'الملفات',
                  Icons.folder_open,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: FilledButton.icon(
                              style: _btnStyle,
                              onPressed: _busy ? null : _pickFiles,
                              icon: const Icon(Icons.folder_open),
                              label: const Text('ملفات'),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: FilledButton.tonalIcon(
                              style: _btnStyle,
                              onPressed: _busy ? null : _pickCamera,
                              icon: const Icon(Icons.camera_alt),
                              label: const Text('كاميرا'),
                            ),
                          ),
                        ],
                      ),
                      if (_items.isNotEmpty) ...[
                        const SizedBox(height: 14),
                        _filesPreview(),
                        const SizedBox(height: 6),
                        Align(
                          alignment: AlignmentDirectional.centerEnd,
                          child: TextButton.icon(
                            onPressed: _busy ? null : _clear,
                            icon: const Icon(Icons.delete_outline, size: 18),
                            label: const Text('مسح الكل'),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                _section(
                  2,
                  'الإعدادات',
                  Icons.settings,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _field(_serverCtrl, 'رابط السيرفر', Icons.link),
                      _field(_keyCtrl, 'مفتاح الرفع', Icons.vpn_key, obscure: true),
                      OutlinedButton.icon(
                        onPressed: _saveSettings,
                        icon: const Icon(Icons.save_outlined),
                        label: const Text('حفظ الإعدادات'),
                      ),
                    ],
                  ),
                ),
                _section(
                  3,
                  'رمز فتح الألبوم',
                  Icons.lock_outline,
                  _field(_codeCtrl, 'الرمز (4 أحرف أو أرقام أو أكثر)', Icons.password),
                ),
                _section(
                  4,
                  'الـQR',
                  Icons.qr_code_2,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      FilledButton.icon(
                        style: _btnStyle,
                        onPressed: _busy ? null : _generate,
                        icon: _busy
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.auto_awesome),
                        label: Text(_busy ? 'جاري العمل...' : 'توليد QR'),
                      ),
                      const SizedBox(height: 12),
                      _statusBar(),
                      if (_qrData != null) ...[
                        const SizedBox(height: 16),
                        Center(
                          child: Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: QrImageView(data: _qrData!, size: 240),
                          ),
                        ),
                        const SizedBox(height: 12),
                        FilledButton.icon(
                          style: _btnStyle,
                          onPressed: _saveQr,
                          icon: const Icon(Icons.download),
                          label: const Text('حفظ الـQR في المعرض'),
                        ),
                        const SizedBox(height: 10),
                        FilledButton.tonalIcon(
                          style: _btnStyle,
                          onPressed: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => AlbumPage(url: _qrData!),
                              ),
                            );
                          },
                          icon: const Icon(Icons.open_in_new),
                          label: const Text('فتح الألبوم هنا'),
                        ),
                        const SizedBox(height: 10),
                        SelectableText(
                          _qrData!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 12, color: Color(0xFFB0BEC5)),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class AlbumPage extends StatefulWidget {
  final String url;
  const AlbumPage({super.key, required this.url});

  @override
  State<AlbumPage> createState() => _AlbumPageState();
}

class _AlbumPageState extends State<AlbumPage> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الألبوم'),
        centerTitle: true,
      ),
      body: WebViewWidget(controller: _controller),
    );
  }
}
