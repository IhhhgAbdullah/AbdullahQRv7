import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:archive/archive.dart';
import 'package:share_plus/share_plus.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:gal/gal.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:qr/qr.dart' as qr;
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String kServerUrl = 'https://887899Abdullah.pythonanywhere.com';
const String kGoogleWebClientId = '1043319001950-4jtv9ofmkghio9i2d814l1shep7sq1g7.apps.googleusercontent.com';

void main() => runApp(const QrPixApp());

class QrPixApp extends StatelessWidget {
  const QrPixApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QR PiX',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorSchemeSeed: const Color(0xFF1E88E5),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class PickedItem {
  final String name;
  final Uint8List bytes;
  final bool isImage;
  PickedItem(this.name, this.bytes, this.isImage);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _serverCtrl = TextEditingController();
  final _keyCtrl = TextEditingController();
  final _codeCtrl = TextEditingController();
  final _cName = TextEditingController();
  final _cTitle = TextEditingController();
  final _cCompany = TextEditingController();
  final _cPhone = TextEditingController();
  final _cEmail = TextEditingController();
  final _cWeb = TextEditingController();
  final _cardKey = GlobalKey();
  String? _cardData;
  int _expireSeconds = 0;
  final _picker = ImagePicker();

  final List<PickedItem> _items = [];
  String? _qrData;
  String _status = 'اختر ملفات أو صور أولًا';
  bool _busy = false;
  String? _token;
  Color _qrColor = const Color(0xFF0B1D3A);
  Uint8List? _logoBytes;
  Offset _logoPos = const Offset(92, 92);
  List<List<String>> _batchRows = [];
  int _batchCount = 0;
  final _qrKey = GlobalKey();
  final _googleSignIn = GoogleSignIn(
    scopes: ['email', 'https://www.googleapis.com/auth/drive.file'],
    serverClientId: kGoogleWebClientId,
  );
  String _email = '';
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  @override
  void dispose() {
    _serverCtrl.dispose();
    _keyCtrl.dispose();
    _codeCtrl.dispose();
    _cName.dispose();
    _cTitle.dispose();
    _cCompany.dispose();
    _cPhone.dispose();
    _cEmail.dispose();
    _cWeb.dispose();
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadSettings() async {
    final p = await SharedPreferences.getInstance();
    _serverCtrl.text = kServerUrl;
    if (mounted) {
      setState(() {
        _token = p.getString('token');
        _email = p.getString('email') ?? '';
      });
    }
  }

  Future<void> _auth(String mode) async {
    final email = _emailCtrl.text.trim().toLowerCase();
    final pass = _passCtrl.text;
    if (!email.contains('@') || pass.length < 6) {
      _say('أدخل بريد صحيح وكلمة سر 6 أحرف على الأقل');
      return;
    }
    setState(() => _busy = true);
    try {
      final res = await http.post(
        Uri.parse('${_serverBase()}/$mode'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email, 'password': pass}),
      ).timeout(const Duration(seconds: 30));
      final j = jsonDecode(res.body) as Map<String, dynamic>;
      if (res.statusCode != 200 || j['token'] == null) {
        throw Exception(j['error'] ?? 'HTTP ${res.statusCode}');
      }
      final p = await SharedPreferences.getInstance();
      await p.setString('token', j['token'] as String);
      await p.setString('email', email);
      _passCtrl.clear();
      if (mounted) {
        setState(() {
          _token = j['token'] as String;
          _email = email;
          _status = 'أهلًا بك';
        });
      }
    } catch (e) {
      _say('خطأ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _googleLogin() async {
    setState(() => _busy = true);
    try {
      final acc = await _googleSignIn.signIn().timeout(const Duration(seconds: 60));
      if (acc == null) {
        _say('تم إلغاء تسجيل الدخول');
        return;
      }
      final auth = await acc.authentication;
      final idToken = auth.idToken;
      if (idToken == null) throw Exception('ما وصل توكن من Google');
      final res = await http.post(
        Uri.parse('${_serverBase()}/google'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'idToken': idToken}),
      ).timeout(const Duration(seconds: 30));
      final j = jsonDecode(res.body) as Map<String, dynamic>;
      if (res.statusCode != 200 || j['token'] == null) {
        throw Exception(j['error'] ?? 'HTTP ${res.statusCode}');
      }
      final p = await SharedPreferences.getInstance();
      await p.setString('token', j['token'] as String);
      await p.setString('email', j['email'] as String);
      if (mounted) {
        setState(() {
          _token = j['token'] as String;
          _email = j['email'] as String;
          _status = 'أهلًا بك';
        });
      }
    } catch (e) {
      _say('خطأ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _logout() async {
    final p = await SharedPreferences.getInstance();
    await p.remove('token');
    await p.remove('email');
    if (mounted) {
      setState(() {
        _token = null;
        _email = '';
        _items.clear();
        _qrData = null;
        _status = 'تم تسجيل الخروج';
      });
    }
  }

  Future<void> _saveSettings() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('server', _serverCtrl.text.trim());
    await p.setString('upkey', _keyCtrl.text.trim());
    _say('تم حفظ الإعدادات');
  }

  void _say(String s) {
    if (mounted) setState(() => _status = s);
  }

  void _changed() {
    setState(() {
      _qrData = null;
      _status = 'عدد الملفات: ${_items.length}';
    });
  }

  Future<void> _pickFiles() async {
    const group = XTypeGroup(
      label: 'PDF والصور',
      extensions: ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'gif'],
    );
    final files = await openFiles(acceptedTypeGroups: [group]);
    for (final f in files) {
      final bytes = await f.readAsBytes();
      final ext = f.name.split('.').last.toLowerCase();
      final isImage = ['jpg', 'jpeg', 'png', 'webp', 'gif'].contains(ext);
      _items.add(PickedItem(f.name, bytes, isImage));
    }
    _changed();
  }

  Future<void> _pickMany() async {
    final files = await _picker.pickMultiImage(imageQuality: 100);
    for (final f in files) {
      _items.add(PickedItem(f.name, await f.readAsBytes(), true));
    }
    if (files.isNotEmpty) {
      _changed();
    }
  }

  Future<void> _openGallery() async {
    // The system photo picker opens without a permission prompt.
    await _pickMany();
  }

  void _openAlbum() {
    final url = _qrData;
    if (url == null) return;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => AlbumPage(url: url)));
  }

  List<List<String>> _parseCsv(Uint8List bytes) {
    final text = utf8.decode(bytes, allowMalformed: true);
    return text
        .split(RegExp(r'\r?\n'))
        .where((l) => l.trim().isNotEmpty)
        .map((l) => l.split(',').map((c) => c.trim().replaceAll('"', '')).toList())
        .toList();
  }

  String _unescapeXml(String v) => v
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>')
      .replaceAll('&quot;', '"')
      .replaceAll('&apos;', "'")
      .replaceAll('&amp;', '&');

  int _colIndex(String letters) {
    var n = 0;
    for (final ch in letters.codeUnits) {
      n = n * 26 + (ch - 64);
    }
    return n - 1;
  }

  // Reads every sheet of an .xlsx file and returns the rows of the sheet that has the most links
  List<List<String>> _parseXlsx(Uint8List bytes) {
    final arc = ZipDecoder().decodeBytes(bytes);
    String? readFile(String name) {
      for (final f in arc.files) {
        if (f.isFile && f.name == name) {
          return utf8.decode(f.content as List<int>, allowMalformed: true);
        }
      }
      return null;
    }

    final shared = <String>[];
    final sst = readFile('xl/sharedStrings.xml');
    if (sst != null) {
      for (final m in RegExp(r'<si>(.*?)</si>', dotAll: true).allMatches(sst)) {
        final text = RegExp(r'<t[^>]*>(.*?)</t>', dotAll: true)
            .allMatches(m.group(1)!)
            .map((x) => _unescapeXml(x.group(1)!))
            .join();
        shared.add(text);
      }
    }

    List<List<String>> parseSheet(String xml) {
      final rows = <List<String>>[];
      for (final rm in RegExp(r'<row[^>]*>(.*?)</row>', dotAll: true).allMatches(xml)) {
        final cells = <int, String>{};
        for (final cm in RegExp(r'<c ([^>]*?)(?:/>|>(.*?)</c>)', dotAll: true).allMatches(rm.group(1)!)) {
          final attrs = cm.group(1)!;
          final body = cm.group(2) ?? '';
          final ref = RegExp(r'r="([A-Z]+)\d+"').firstMatch(attrs)?.group(1) ?? 'A';
          final type = RegExp(r't="([^"]+)"').firstMatch(attrs)?.group(1);
          String value = '';
          if (type == 's') {
            final idx = int.tryParse(RegExp(r'<v>(\d+)</v>').firstMatch(body)?.group(1) ?? '');
            if (idx != null && idx < shared.length) value = shared[idx];
          } else if (type == 'inlineStr') {
            value = RegExp(r'<t[^>]*>(.*?)</t>', dotAll: true)
                .allMatches(body)
                .map((x) => _unescapeXml(x.group(1)!))
                .join();
          } else {
            value = _unescapeXml(RegExp(r'<v>(.*?)</v>', dotAll: true).firstMatch(body)?.group(1) ?? '');
          }
          cells[_colIndex(ref)] = value.trim();
        }
        if (cells.isEmpty) {
          rows.add([]);
          continue;
        }
        final maxCol = cells.keys.reduce((x, y) => x > y ? x : y);
        rows.add(List.generate(maxCol + 1, (i) => cells[i] ?? ''));
      }
      return rows;
    }

    List<List<String>> best = [];
    int bestLinks = -1;
    for (final f in arc.files) {
      if (!f.isFile || !f.name.startsWith('xl/worksheets/sheet') || !f.name.endsWith('.xml')) continue;
      final rows = parseSheet(utf8.decode(f.content as List<int>, allowMalformed: true));
      final links = rows.where((r) => r.any((c) => c.toLowerCase().startsWith('http'))).length;
      if (links > bestLinks) {
        bestLinks = links;
        best = rows;
      }
    }
    if (bestLinks < 0) throw Exception('ما لقيت ورقة في الملف');
    return best;
  }

  Future<void> _pickBatchFile() async {
    const group = XTypeGroup(
      label: 'Excel أو CSV',
      extensions: ['xlsx', 'csv'],
      mimeTypes: [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-excel',
        'text/csv',
        'application/octet-stream',
      ],
    );
    final file = await openFile(acceptedTypeGroups: [group]).timeout(const Duration(seconds: 120));
    if (file == null) {
      _say('ما اخترت ملف');
      return;
    }
    _say('تم اختيار: ${file.name}');
    try {
      final bytes = await file.readAsBytes();
      _say('تم تحميل الملف (${bytes.length} بايت)، جاري التحليل...');
      final isCsv = file.name.toLowerCase().endsWith('.csv');
      final rows = isCsv ? _parseCsv(bytes) : _parseXlsx(bytes);
      _say('تم تحليل ${rows.length} صف، جاري البحث عن الروابط...');
      final valid = <List<String>>[];
      for (final r in rows) {
        final li = r.indexWhere((c) => c.toLowerCase().startsWith('http'));
        if (li < 0) continue;
        var name = '';
        for (var i = 0; i < r.length; i++) {
          if (i != li && r[i].isNotEmpty && !r[i].toLowerCase().startsWith('http')) {
            name = r[i];
            break;
          }
        }
        valid.add([r[li], name]);
      }
      if (valid.isEmpty) {
        _say('ما لقيت روابط (http) في الملف');
        return;
      }
      final limited = valid.take(500).toList();
      setState(() {
        _batchRows = limited;
        _batchCount = limited.length;
      });
      _say('تم قراءة $_batchCount رابط${valid.length > 500 ? ' (أول 500 فقط)' : ''}');
    } catch (e) {
      _say('تعذر قراءة الملف: $e');
    }
  }

  Future<Uint8List> _qrPngBytes(String data) async {
    const double size = 600;
    final painter = QrPainter(data: data, version: QrVersions.auto, gapless: true);
    final recorder = ui.PictureRecorder();
    final canvas = ui.Canvas(recorder, ui.Rect.fromLTWH(0, 0, size, size));
    canvas.drawRect(ui.Rect.fromLTWH(0, 0, size, size), ui.Paint()..color = Colors.white);
    painter.paint(canvas, const Size(size, size));
    final picture = recorder.endRecording();
    final image = await picture.toImage(size.toInt(), size.toInt());
    final bd = await image.toByteData(format: ui.ImageByteFormat.png);
    return bd!.buffer.asUint8List();
  }

  Future<void> _makeBatchZip() async {
    if (_batchRows.isEmpty) {
      _say('اختر ملف Excel أو CSV أولًا');
      return;
    }
    setState(() => _busy = true);
    try {
      final archive = Archive();
      for (var i = 0; i < _batchRows.length; i++) {
        _say('إنشاء الرمز ${i + 1} من ${_batchRows.length}...');
        final row = _batchRows[i];
        final rawName = row.length > 1 && row[1].isNotEmpty ? row[1] : 'qr_${i + 1}';
        final safe = rawName.replaceAll(RegExp(r'[^A-Za-z0-9\u0600-\u06FF_-]+'), '_');
        final png = await _qrPngBytes(row[0]);
        archive.addFile(ArchiveFile('${i + 1}_$safe.png', png.length, png));
      }
      final encoded = ZipEncoder().encode(archive);
      if (encoded == null) throw Exception('تعذر إنشاء ملف ZIP');
      final zipBytes = Uint8List.fromList(encoded);
      await Share.shareXFiles(
        [XFile.fromData(zipBytes, name: 'qr_codes.zip', mimeType: 'application/zip')],
        text: 'QR PiX - رموز QR جماعية',
      );
      _say('تم إنشاء ${_batchRows.length} رمز في ملف ZIP');
    } catch (e) {
      _say('خطأ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _pickCamera() async {
    final f = await _picker.pickImage(source: ImageSource.camera, imageQuality: 100);
    if (f == null) return;
    _items.add(PickedItem(f.name, await f.readAsBytes(), true));
    _changed();
  }

  void _clear() {
    setState(() {
      _items.clear();
      _qrData = null;
      _status = 'اختر ملفات أو صور أولًا';
    });
  }

  String _serverBase() => _serverCtrl.text.trim().replaceAll(RegExp(r'/$'), '');

  // Server asks Gemini (key stays on the server). Returns [x, y, w, h] or null.
  Future<List<double>?> _askCrop(Uint8List bytes) async {
    try {
      final req = http.MultipartRequest('POST', Uri.parse('${_serverBase()}/crop'))
        ..headers['Authorization'] = 'Bearer ${_token ?? ''}'
        ..files.add(http.MultipartFile.fromBytes(
          'file',
          bytes,
          filename: 'crop.jpg',
          contentType: MediaType('image', 'jpeg'),
        ));
      final streamed = await req.send().timeout(const Duration(seconds: 120));
      final body = await streamed.stream.bytesToString();
      final j = jsonDecode(body) as Map<String, dynamic>;
      final box = j['box'];
      if (box is List && box.length == 4) {
        return box.map((e) => (e as num).toDouble()).toList();
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  Uint8List _cropAndEnhance(Uint8List bytes, List<double>? box) {
    var im = img.decodeImage(bytes);
    if (im == null) return bytes;
    if (box != null) {
      final x = (box[0] * im.width).round();
      final y = (box[1] * im.height).round();
      final w = (box[2] * im.width).round();
      final h = (box[3] * im.height).round();
      im = img.copyCrop(im, x: x, y: y, width: w, height: h);
    }
    im = img.normalize(im, min: 0, max: 255);
    return Uint8List.fromList(img.encodeJpg(im, quality: 92));
  }

  String _mimeFor(String name) {
    final ext = name.split('.').last.toLowerCase();
    switch (ext) {
      case 'pdf':
        return 'application/pdf';
      case 'doc':
        return 'application/msword';
      case 'docx':
        return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      case 'png':
        return 'image/png';
      case 'webp':
        return 'image/webp';
      case 'gif':
        return 'image/gif';
      default:
        return 'image/jpeg';
    }
  }

  Future<String> _uploadOne(Uint8List bytes, String name, String mime) async {
    final req = http.MultipartRequest('POST', Uri.parse('${_serverBase()}/upload'))
      ..headers['Authorization'] = 'Bearer ${_token ?? ''}'
      ..files.add(http.MultipartFile.fromBytes(
        'file',
        bytes,
        filename: name,
        contentType: MediaType.parse(mime),
      ));

    final streamed = await req.send().timeout(const Duration(seconds: 120));
    final body = await streamed.stream.bytesToString();
    final j = jsonDecode(body) as Map<String, dynamic>;
    if (streamed.statusCode != 200 || j['url'] == null) {
      throw Exception(j['error'] ?? 'HTTP ${streamed.statusCode}');
    }
    return j['url'] as String;
  }

  Future<String> _createAlbum(List<String> urls, String code) async {
    final res = await http.post(
      Uri.parse('${_serverBase()}/album'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${_token ?? ''}',
      },
      body: jsonEncode({'urls': urls, 'code': code, if (_expireSeconds > 0) 'expires_in': _expireSeconds}),
    ).timeout(const Duration(seconds: 60));
    final j = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200 || j['url'] == null) {
      throw Exception(j['error'] ?? 'HTTP ${res.statusCode}');
    }
    return j['url'] as String;
  }

  Future<String> _driveAccessToken() async {
    GoogleSignInAccount? acc = _googleSignIn.currentUser ?? await _googleSignIn.signInSilently();
    if (acc == null) throw Exception('سجّل دخول بحساب Google أولًا');
    final auth = await acc.authentication;
    final t = auth.accessToken;
    if (t == null) throw Exception('ما قدرت أحصل على صلاحية Drive');
    return t;
  }

  // Uploads to the user's own Drive and makes the file readable by link
  Future<String> _driveUpload(Uint8List bytes, String name, String mime, String token) async {
    const boundary = 'qrpixboundary';
    final body = BytesBuilder()
      ..add(utf8.encode('--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n'))
      ..add(utf8.encode(jsonEncode({'name': name})))
      ..add(utf8.encode('\r\n--$boundary\r\nContent-Type: $mime\r\n\r\n'))
      ..add(bytes)
      ..add(utf8.encode('\r\n--$boundary--'));
    final res = await http.post(
      Uri.parse('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id'),
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'multipart/related; boundary=$boundary',
      },
      body: body.toBytes(),
    ).timeout(const Duration(seconds: 120));
    final j = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200 || j['id'] == null) {
      throw Exception('Drive ${res.statusCode}');
    }
    final id = j['id'] as String;
    await http.post(
      Uri.parse('https://www.googleapis.com/drive/v3/files/$id/permissions'),
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode({'role': 'reader', 'type': 'anyone'}),
    );
    return id;
  }

  Future<void> _generate() async {
    if (_items.isEmpty) {
      _say('اختر ملفًا واحدًا على الأقل');
      return;
    }
    if (_serverBase().isEmpty) {
      _say('رابط السيرفر غير مضبوط');
      return;
    }
    final code = _codeCtrl.text.trim();
    if (code.length < 4) {
      _say('اكتب رمز فتح من 4 أحرف أو أرقام على الأقل');
      return;
    }

    setState(() => _busy = true);
    try {
      final urls = <String>[];
      String? driveToken;
      try {
        driveToken = await _driveAccessToken();
      } catch (_) {
        driveToken = null;
      }
      for (var i = 0; i < _items.length; i++) {
        final it = _items[i];
        _say('رفع ${i + 1} من ${_items.length}...');
        if (it.isImage) {
          final box = await _askCrop(it.bytes);
          final out = _cropAndEnhance(it.bytes, box);
          if (driveToken != null) {
            final id = await _driveUpload(out, 'qrpix_${DateTime.now().millisecondsSinceEpoch}.jpg', 'image/jpeg', driveToken);
            urls.add('https://drive.google.com/thumbnail?id=$id&sz=w1200');
          } else {
            urls.add(await _uploadOne(out, 'qrpix.jpg', 'image/jpeg'));
          }
        } else {
          if (driveToken != null) {
            final id = await _driveUpload(it.bytes, it.name, _mimeFor(it.name), driveToken);
            urls.add('https://drive.google.com/file/d/$id/view');
          } else {
            urls.add(await _uploadOne(it.bytes, it.name, _mimeFor(it.name)));
          }
        }
      }

      _say('إنشاء الألبوم...');
      final albumUrl = await _createAlbum(urls, code);
      if (mounted) {
        setState(() {
          _qrData = albumUrl;
          _status = 'تم. الماسح يطلب الرمز ثم يفتح ${urls.length} ملف';
        });
      }
    } catch (e) {
      _say('خطأ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _makeCard() {
    String v(TextEditingController c) => c.text.trim().replaceAll(RegExp(r'[\r\n;,]'), ' ');
    final name = v(_cName);
    if (name.isEmpty) {
      _say('اكتب الاسم أولًا');
      return;
    }
    final lines = <String>[
      'BEGIN:VCARD',
      'VERSION:3.0',
      'FN:$name',
      if (v(_cCompany).isNotEmpty) 'ORG:${v(_cCompany)}',
      if (v(_cTitle).isNotEmpty) 'TITLE:${v(_cTitle)}',
      if (v(_cPhone).isNotEmpty) 'TEL;TYPE=CELL:${v(_cPhone)}',
      if (v(_cEmail).isNotEmpty) 'EMAIL:${v(_cEmail)}',
      if (v(_cWeb).isNotEmpty) 'URL:${v(_cWeb)}',
      'END:VCARD',
    ];
    setState(() => _cardData = lines.join('\n'));
    _say('تم توليد البطاقة');
  }

  Future<void> _saveCard() async {
    if (_cardData == null) return;
    try {
      final boundary = _cardKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) {
        _say('تعذر تجهيز البطاقة');
        return;
      }
      final image = await boundary.toImage(pixelRatio: 4);
      final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
      if (bytes == null) {
        _say('تعذر تجهيز البطاقة');
        return;
      }
      await Gal.putImageBytes(
        bytes.buffer.asUint8List(),
        name: 'qr_card_${DateTime.now().millisecondsSinceEpoch}.png',
      );
      _say('تم حفظ البطاقة في المعرض');
    } catch (e) {
      _say('تعذر الحفظ: $e');
    }
  }

  Future<void> _saveQr() async {
    if (_qrData == null) return;
    try {
      final boundary = _qrKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) {
        _say('تعذر تجهيز صورة الـQR');
        return;
      }
      final image = await boundary.toImage(pixelRatio: 4);
      final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
      if (bytes == null) {
        _say('تعذر تجهيز صورة الـQR');
        return;
      }
      await Gal.putImageBytes(
        bytes.buffer.asUint8List(),
        name: 'qr_pix_${DateTime.now().millisecondsSinceEpoch}.png',
      );
      _say('تم حفظ الصورة في المعرض');
    } catch (e) {
      _say('تعذر الحفظ: $e');
    }
  }

  double _clampPos(double v) => v < 0 ? 0 : (v > 184 ? 184 : v);

  Future<void> _pickLogo() async {
    final f = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (f == null) return;
    final bytes = await f.readAsBytes();
    setState(() {
      _logoBytes = bytes;
      _logoPos = const Offset(92, 92);
    });
  }

  Widget _section(int number, String title, IconData icon, Widget child) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xE60B1D3A),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0x33F1D77A)),
        boxShadow: const [
          BoxShadow(color: Colors.black38, blurRadius: 16, offset: Offset(0, 6)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 15,
                backgroundColor: const Color(0xFFF1D77A),
                child: Text(
                  '$number',
                  style: const TextStyle(color: Color(0xFF0B1D3A), fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(width: 10),
              Icon(icon, color: const Color(0xFF64B5F6), size: 20),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFFF4F1E6),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }

  Widget _loginScreen() {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(child: Image.asset('assets/bg.png', fit: BoxFit.cover)),
          Positioned.fill(child: Container(color: const Color(0xE60B1D3A))),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Container(
                  constraints: const BoxConstraints(maxWidth: 420),
                  padding: const EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    color: const Color(0xE60B1D3A),
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: const Color(0x33F1D77A)),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text(
                        'QR PiX',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.w800,
                          color: Color(0xFFF1D77A),
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'سجّل دخولك أو أنشئ حسابًا',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Color(0xFFB0BEC5)),
                      ),
                      const SizedBox(height: 18),
                      _field(_emailCtrl, 'البريد الإلكتروني', Icons.email_outlined),
                      _field(_passCtrl, 'كلمة السر (6 أحرف أو أكثر)', Icons.lock_outline, obscure: true),
                      const SizedBox(height: 6),
                      FilledButton(
                        style: _btnStyle,
                        onPressed: _busy ? null : () => _auth('login'),
                        child: Text(_busy ? 'جاري التحقق...' : 'تسجيل الدخول'),
                      ),
                      const SizedBox(height: 10),
                      OutlinedButton(
                        onPressed: _busy ? null : () => _auth('register'),
                        child: const Text('إنشاء حساب جديد'),
                      ),
                      const SizedBox(height: 10),
                      FilledButton.icon(
                        style: FilledButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: Colors.black87,
                          minimumSize: const Size.fromHeight(50),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        onPressed: _busy ? null : _googleLogin,
                        icon: const Text('G', style: TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF4285F4), fontSize: 18)),
                        label: const Text('المتابعة باستخدام Google'),
                      ),
                      const SizedBox(height: 14),
                      Text(
                        _status,
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Color(0xFFFF8A80)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _field(TextEditingController c, String label, IconData icon, {bool obscure = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: c,
        obscureText: obscure,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon, size: 20),
          filled: true,
          fillColor: const Color(0xFF0B1D3A),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0x33F1D77A)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFF1D77A)),
          ),
        ),
      ),
    );
  }

  ButtonStyle get _btnStyle => FilledButton.styleFrom(
        minimumSize: const Size.fromHeight(50),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
      );

  Widget _filesPreview() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final it in _items)
          it.isImage
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.memory(it.bytes, width: 76, height: 76, fit: BoxFit.cover),
                )
              : Container(
                  width: 76,
                  height: 76,
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF13294F),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.picture_as_pdf, color: Color(0xFFF1D77A)),
                      const SizedBox(height: 4),
                      Text(
                        it.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 10),
                      ),
                    ],
                  ),
                ),
      ],
    );
  }

  Widget _statusBar() {
    final isError = _status.startsWith('خطأ') || _status.startsWith('تعذر');
    final isOk = _status.startsWith('تم');
    final color = isError
        ? const Color(0xFFFF8A80)
        : isOk
            ? const Color(0xFF81C784)
            : const Color(0xFFB0BEC5);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Row(
        children: [
          Icon(
            isError ? Icons.error_outline : (isOk ? Icons.check_circle_outline : Icons.info_outline),
            color: color,
            size: 20,
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(_status, style: TextStyle(color: color))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_token == null) return _loginScreen();
    return Scaffold(
      extendBodyBehindAppBar: false,
      appBar: AppBar(
        backgroundColor: const Color(0xFF0B1D3A),
        elevation: 0,
        centerTitle: true,
        actions: [
          IconButton(
            tooltip: 'تسجيل الخروج',
            onPressed: _logout,
            icon: const Icon(Icons.logout),
          ),
        ],
        title: const Text(
          'QR PiX',
          style: TextStyle(
            fontWeight: FontWeight.w800,
            letterSpacing: 1.2,
            color: Color(0xFFF1D77A),
          ),
        ),
      ),
      body: Stack(
        children: [
          Positioned.fill(child: Image.asset('assets/bg.png', fit: BoxFit.cover)),
          const Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xB30B1D3A), Color(0xF20B1D3A)],
                ),
              ),
            ),
          ),
          SafeArea(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
              children: [
                _section(
                  1,
                  'الملفات',
                  Icons.folder_open,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: FilledButton.icon(
                              style: _btnStyle,
                              onPressed: _busy ? null : _openGallery,
                              icon: const Icon(Icons.photo_library),
                              label: const Text('معرض الصور'),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: FilledButton.tonalIcon(
                              style: _btnStyle,
                              onPressed: _busy ? null : _pickCamera,
                              icon: const Icon(Icons.camera_alt),
                              label: const Text('كاميرا'),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      OutlinedButton.icon(
                        style: _btnStyle,
                        onPressed: _busy ? null : _pickFiles,
                        icon: const Icon(Icons.picture_as_pdf),
                        label: const Text('ملفات PDF'),
                      ),
                      const SizedBox(height: 10),
                      if (_items.isNotEmpty) ...[
                        const SizedBox(height: 14),
                        _filesPreview(),
                        const SizedBox(height: 6),
                        Align(
                          alignment: AlignmentDirectional.centerEnd,
                          child: TextButton.icon(
                            onPressed: _busy ? null : _clear,
                            icon: const Icon(Icons.delete_outline, size: 18),
                            label: const Text('مسح الكل'),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                _section(
                  2,
                  'رمز فتح الألبوم',
                  Icons.lock_outline,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                  _field(_codeCtrl, 'الرمز (4 أحرف أو أرقام أو أكثر)', Icons.password),
                  DropdownButtonFormField<int>(
                    initialValue: _expireSeconds,
                    decoration: const InputDecoration(
                      labelText: 'مدة صلاحية الرمز',
                      border: OutlineInputBorder(),
                    ),
                    items: const [
                      DropdownMenuItem(value: 0, child: Text('بدون انتهاء')),
                      DropdownMenuItem(value: 3600, child: Text('ساعة واحدة')),
                      DropdownMenuItem(value: 86400, child: Text('يوم واحد')),
                      DropdownMenuItem(value: 604800, child: Text('أسبوع')),
                    ],
                    onChanged: (v) => setState(() => _expireSeconds = v ?? 0),
                  ),
                  const SizedBox(height: 12),
                    ],
                  ),
                ),
                _section(
                  3,
                  'رمز QR',
                  Icons.qr_code_2,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      FilledButton.icon(
                        style: _btnStyle,
                        onPressed: _busy ? null : _generate,
                        icon: _busy
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.auto_awesome),
                        label: Text(_busy ? 'جاري العمل...' : 'توليد QR'),
                      ),
                      const SizedBox(height: 12),
                      _statusBar(),
                      if (_qrData != null) ...[
                        const SizedBox(height: 16),
                        Wrap(
                          spacing: 10,
                          runSpacing: 10,
                          alignment: WrapAlignment.center,
                          children: [
                            for (final c in const [
                              Color(0xFF0B1D3A),
                              Color(0xFF000000),
                              Color(0xFF1B5E20),
                              Color(0xFF6A1B9A),
                              Color(0xFFB71C1C),
                            ])
                              GestureDetector(
                                onTap: () => setState(() => _qrColor = c),
                                child: CircleAvatar(
                                  radius: 14,
                                  backgroundColor: c,
                                  child: _qrColor == c
                                      ? const Icon(Icons.check, color: Colors.white, size: 16)
                                      : null,
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 8,
                          alignment: WrapAlignment.center,
                          children: [
                            OutlinedButton.icon(
                              onPressed: _pickLogo,
                              icon: const Icon(Icons.image_outlined),
                              label: const Text('إضافة شعار'),
                            ),
                            if (_logoBytes != null)
                              TextButton(
                                onPressed: () => setState(() => _logoBytes = null),
                                child: const Text('إزالة الشعار'),
                              ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Center(
                          child: RepaintBoundary(
                            key: _qrKey,
                            child: Container(
                              padding: const EdgeInsets.all(14),
                              color: Colors.white,
                              child: SizedBox(
                                width: 240,
                                height: 240,
                                child: Stack(
                                  children: [
                                    QrImageView(
                                      data: _qrData!,
                                      size: 240,
                                      errorCorrectionLevel: qr.QrErrorCorrectLevel.H,
                                      eyeStyle: QrEyeStyle(eyeShape: QrEyeShape.square, color: _qrColor),
                                      dataModuleStyle: QrDataModuleStyle(
                                        dataModuleShape: QrDataModuleShape.square,
                                        color: _qrColor,
                                      ),
                                    ),
                                    if (_logoBytes != null)
                                      Positioned(
                                        left: _logoPos.dx,
                                        top: _logoPos.dy,
                                        child: GestureDetector(
                                          onPanUpdate: (d) => setState(() {
                                            _logoPos = Offset(
                                              _clampPos(_logoPos.dx + d.delta.dx),
                                              _clampPos(_logoPos.dy + d.delta.dy),
                                            );
                                          }),
                                          child: ClipRRect(
                                            borderRadius: BorderRadius.circular(8),
                                            child: Image.memory(
                                              _logoBytes!,
                                              width: 56,
                                              height: 56,
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        FilledButton.icon(
                          style: _btnStyle,
                          onPressed: _saveQr,
                          icon: const Icon(Icons.download),
                          label: const Text('حفظ الـQR في المعرض'),
                        ),
                        const SizedBox(height: 10),
                        FilledButton.tonalIcon(
                          style: _btnStyle,
                          onPressed: _openAlbum,
                          icon: const Icon(Icons.open_in_new),
                          label: const Text('فتح الألبوم هنا'),
                        ),
                        const SizedBox(height: 10),
                        SelectableText(
                          _qrData!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 12, color: Color(0xFFB0BEC5)),
                        ),
                      ],
                    ],
                  ),
                ),
          if (_batchCount > 0)
          _section(
            5,
            'QR جماعي (حتى 500)',
            Icons.grid_view,
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  _batchCount == 0
                      ? 'اختر ملف Excel أو CSV من القسم 1 أولاً'
                      : 'الروابط الجاهزة من الملف',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12, color: Color(0xFFB0BEC5)),
                ),
                if (_batchCount > 0) ...[
                  const SizedBox(height: 8),
                  Text('عدد الروابط: $_batchCount', textAlign: TextAlign.center),
                  const SizedBox(height: 10),
                  FilledButton.icon(
                    style: _btnStyle,
                    onPressed: _busy ? null : _makeBatchZip,
                    icon: const Icon(Icons.archive),
                    label: const Text('إنشاء ZIP وحفظه'),
                  ),
                ],
              ],
            ),
          ),
          _section(
            6,
            'بطاقة QR شخصية',
            Icons.badge,
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _field(_cName, 'الاسم', Icons.person),
                _field(_cTitle, 'الوظيفة', Icons.work_outline),
                _field(_cCompany, 'الشركة', Icons.business),
                _field(_cPhone, 'رقم الهاتف', Icons.phone),
                _field(_cEmail, 'الإيميل', Icons.email_outlined),
                _field(_cWeb, 'الموقع أو رابط التواصل', Icons.link),
                FilledButton.icon(
                  style: _btnStyle,
                  onPressed: _makeCard,
                  icon: const Icon(Icons.badge),
                  label: const Text('توليد بطاقة QR'),
                ),
                if (_cardData != null) ...[
                  const SizedBox(height: 12),
                  Center(
                    child: RepaintBoundary(
                      key: _cardKey,
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        color: Colors.white,
                        child: QrImageView(
                          data: _cardData!,
                          size: 220,
                          errorCorrectionLevel: qr.QrErrorCorrectLevel.M,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  FilledButton.icon(
                    style: _btnStyle,
                    onPressed: _saveCard,
                    icon: const Icon(Icons.download),
                    label: const Text('حفظ البطاقة في المعرض'),
                  ),
                ],
              ],
            ),
          ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class AlbumPage extends StatefulWidget {
  final String url;
  const AlbumPage({super.key, required this.url});

  @override
  State<AlbumPage> createState() => _AlbumPageState();
}

class _AlbumPageState extends State<AlbumPage> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onNavigationRequest: (request) {
            final uri = Uri.parse(request.url);
            final isWeb = uri.scheme == 'http' || uri.scheme == 'https';
            if (isWeb && uri.host == 'drive.google.com' && uri.path.startsWith('/thumbnail')) {
              _saveImage(uri);
              return NavigationDecision.prevent;
            }
            if (isWeb && uri.host != 't.me' && uri.host != 'telegram.me') {
              return NavigationDecision.navigate;
            }
            // Telegram links and other app schemes open outside the WebView
            launchUrl(uri, mode: LaunchMode.externalApplication);
            return NavigationDecision.prevent;
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.url));
  }

  Future<void> _saveImage(Uri uri) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      final res = await http.get(uri);
      if (res.statusCode != 200) throw Exception('HTTP ${res.statusCode}');
      await Gal.putImageBytes(
        res.bodyBytes,
        name: 'qr_pix_${DateTime.now().millisecondsSinceEpoch}.jpg',
      );
      messenger.showSnackBar(const SnackBar(content: Text('تم حفظ الصورة في المعرض')));
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('تعذر الحفظ: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الألبوم'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            color: const Color(0xFF13294F),
            child: const Text(
              'اضغط على أي صورة لحفظها في جوالك',
              textAlign: TextAlign.center,
              style: TextStyle(color: Color(0xFFF1D77A)),
            ),
          ),
          Expanded(child: WebViewWidget(controller: _controller)),
        ],
      ),
    );
  }
}
